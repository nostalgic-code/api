<?php
// filepath: dev/login.php

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/src/Services/AuthService.php';

$authService = new AuthService();
$sessionManager = new SessionManager();

// If already authenticated, redirect to home
if ($sessionManager->isAuthenticated()) {
    header('Location: /dev/home.php');
    exit;
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    header('Content-Type: application/json');
    
    $action = $_POST['action'] ?? '';
    
    if ($action === 'send_otp') {
        $phone = $_POST['phone'] ?? '';
        
        // Add debugging
        error_log("Login.php: Sending OTP for phone: " . $phone);
        
        $response = $authService->sendOtp($phone);
        
        // Log the response from AuthService
        error_log("Login.php: AuthService response: " . json_encode($response));
        
        echo json_encode($response);
        exit;
    }
    
    if ($action === 'verify_otp') {
        $phone = $_POST['phone'] ?? '';
        $otp = $_POST['otp'] ?? '';
        echo json_encode($authService->verifyOtp($phone, $otp));
        exit;
    }
}

include __DIR__ . '/templates/auth/login-form.php';