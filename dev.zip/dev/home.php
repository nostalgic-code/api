<?php
// filepath: dev/home.php

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/src/Middleware/AuthMiddleware.php';

// Check authentication
$auth = new AuthMiddleware();
$auth->handle();

// Get user data
$sessionManager = new SessionManager();
$user = $sessionManager->getUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <nav class="bg-white shadow">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-16">
                    <div class="flex items-center">
                        <h1 class="text-xl font-semibold"><?= APP_NAME ?></h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-gray-700">Welcome, <?= htmlspecialchars($user['name'] ?? 'User') ?></span>
                        <a href="/dev/logout.php" class="text-red-600 hover:text-red-800">Logout</a>
                    </div>
                </div>
            </div>
        </nav>
        
        <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div class="px-4 py-6 sm:px-0">
                <div class="bg-white overflow-hidden shadow rounded-lg">
                    <div class="px-4 py-5 sm:p-6">
                        <h2 class="text-lg font-medium text-gray-900 mb-4">User Information</h2>
                        <dl class="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Name</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?= htmlspecialchars($user['name'] ?? 'N/A') ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Email</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?= htmlspecialchars($user['email'] ?? 'N/A') ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-gray-500">Phone</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?= htmlspecialchars($user['phone'] ?? 'N/A') ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-gray-500">User Type</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?= htmlspecialchars($sessionManager->get('user_type', 'N/A')) ?></dd>
                            </div>
                        </dl>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>