<?php
// filepath: dev/register.php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/src/Services/AuthService.php';

$auth = new AuthService();

// If user is already logged in, redirect to appropriate page
if ($auth->validateSession()) {
    $userType = $_SESSION['user_type'] ?? 'customer_user';
    $redirectUrl = $userType === 'platform_user' ? '/dev/admin/' : '/dev/home.php';
    header('Location: ' . $redirectUrl);
    exit;
}

// Process registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    try {
        // Get JSON input
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['success' => false, 'message' => 'Invalid request data']);
            exit;
        }
        
        // Register the user
        $result = $auth->register($input);
        
        echo json_encode($result);
        exit;
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'An error occurred during registration',
            'debug' => DEV_MODE ? $e->getMessage() : null
        ]);
        exit;
    }
}

// Display registration form
require_once __DIR__ . '/templates/auth/register-form.php';