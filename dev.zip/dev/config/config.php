<?php
// filepath: dev/config/config.php

// Detect environment based on hostname
$hostname = $_SERVER['HTTP_HOST'] ?? 'localhost';

if (strpos($hostname, 'localhost') !== false || strpos($hostname, '127.0.0.1') !== false) {
    // Local development
    define('DEV_MODE', true);
    define('API_BASE_URL', 'https://api-2lrf.onrender.com');
} else {
    // Production
    define('DEV_MODE', false);
    define('API_BASE_URL', 'https://api-2lrf.onrender.com');
}

define('APP_NAME', 'Danny\'s Auto Spares');

// Session configuration
define('SESSION_LIFETIME', 3600); // 1 hour
define('SESSION_NAME', 'dannys_session_dev');

// Error reporting
if (DEV_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Start session with custom name
session_name(SESSION_NAME);
session_start();