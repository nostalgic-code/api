<?php
// filepath: dev/logout.php

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/src/Services/AuthService.php';

$authService = new AuthService();
$authService->logout();

header('Location: /dev/login.php');
exit;