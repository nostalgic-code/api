<?php
// filepath: dev/admin/dashboard.php
session_start();

require_once __DIR__ . '/../src/Services/AdminService.php';
require_once __DIR__ . '/../src/Services/SessionManager.php';

// Initialize SessionManager
$sessionManager = new SessionManager();

// Check if user is authenticated
if (!$sessionManager->isAuthenticated()) {
    header('Location: /dev/login.php');
    exit;
}

// Check if user is admin/platform user
if (!$sessionManager->isPlatformUser()) {
    header('Location: /dev/403.php');
    exit;
}

// Initialize AdminService
$adminService = new AdminService();

// Get dashboard statistics
$statsResponse = $adminService->getDashboardStats();

// Prepare dashboard data for JavaScript
$dashboardData = [
    'stats' => $statsResponse['data'] ?? [],
    'notifications' => [
        'total_notifications' => $statsResponse['data']['pending_approvals'] ?? 0,
        'pending_users' => $statsResponse['data']['pending_approvals'] ?? 0
    ]
];

// Include notification if present
if (isset($statsResponse['notification'])) {
    $dashboardData['notification'] = $statsResponse['notification'];
}

// Set current page for navigation
$currentPage = 'dashboard';

// Include header
include __DIR__ . '/includes/admin-header.php';
?>

<!-- Main Dashboard Content -->
<main class="p-8">
    <div class="max-w-7xl mx-auto">
        <!-- Page Header -->
        <div class="mb-8">
            <h1 class="text-2xl font-bold text-gray-900">Dashboard</h1>
            <p class="text-gray-600 mt-1">Welcome back! Here's what's happening with your platform today.</p>
        </div>
        
        <!-- Statistics Cards -->
        <?php include __DIR__ . '/../templates/admin/dashboard/stats-grid.php'; ?>
        
        <!-- Charts and Activity Row -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            <!-- Recent Activity -->
            <?php include __DIR__ . '/../templates/admin/dashboard/recent-activity.php'; ?>
            
            <!-- User Distribution Chart -->
            <?php include __DIR__ . '/../templates/admin/dashboard/user-distribution-chart.php'; ?>
        </div>
        
        <!-- Additional Dashboard Components -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            <!-- Customer Status Breakdown -->
            <?php include __DIR__ . '/../templates/admin/dashboard/customer-status-chart.php'; ?>
            
            <!-- Quick Actions -->
            <?php include __DIR__ . '/../templates/admin/dashboard/quick-actions.php'; ?>
        </div>
    </div>
</main>

<!-- Chart.js library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Pass PHP data to JavaScript -->
<script>
    // Initialize dashboard data
    window.dashboardData = <?php echo json_encode($dashboardData); ?>;
</script>

<!-- Admin base JavaScript -->
<script src="/dev/assets/js/admin/admin.js"></script>

<!-- Dashboard specific JavaScript -->
<script src="/dev/assets/js/admin/dashboard.js"></script>

<!-- Toast Container -->
<div id="toastContainer" class="fixed bottom-4 right-4 z-50 space-y-2"></div>

</body>
</html>