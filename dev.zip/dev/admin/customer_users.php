<?php
session_start();

require_once __DIR__ . '/../src/Services/AdminService.php';
require_once __DIR__ . '/../src/Services/SessionManager.php';

// Initialize SessionManager
$sessionManager = new SessionManager();

// Check if user is authenticated
if (!$sessionManager->isAuthenticated()) {
    header('Location: /dev/login.php');
    exit;
}

// Check if user is admin/platform user
if (!$sessionManager->isPlatformUser()) {
    header('Location: /dev/403.php');
    exit;
}

// Initialize AdminService
$adminService = new AdminService();

// Get user data
$user = $sessionManager->getUser();

// Get active tab
$activeTab = $_GET['tab'] ?? 'pending';

// Set current page for navigation
$currentPage = 'customer_users';

// Handle AJAX requests
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
    header('Content-Type: application/json');
    
    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    
    switch ($action) {
        case 'get_pending_users':
            $filters = [];
            if (isset($_GET['search'])) {
                $filters['search'] = $_GET['search'];
            }
            $result = $adminService->getPendingUsers($filters);
            echo json_encode($result);
            exit;
            
        case 'get_active_users':
            $filters = [];
            if (isset($_GET['search'])) {
                $filters['search'] = $_GET['search'];
            }
            if (isset($_GET['role'])) {
                $filters['role'] = $_GET['role'];
            }
            $result = $adminService->getActiveUsers($filters);
            echo json_encode($result);
            exit;
            
        case 'approve_user':
            $input = json_decode(file_get_contents('php://input'), true);
            $userId = $input['user_id'] ?? null;
            
            if (!$userId) {
                echo json_encode([
                    'success' => false,
                    'notification' => [
                        'type' => 'error',
                        'message' => 'User ID is required'
                    ]
                ]);
                exit;
            }
            
            $approvalData = [];
            if (isset($input['depot_access'])) {
                $approvalData['depot_access'] = $input['depot_access'];
            }
            if (isset($input['custom_permissions'])) {
                $approvalData['custom_permissions'] = $input['custom_permissions'];
            }
            
            $result = $adminService->approveUser($userId, $approvalData);
            echo json_encode($result);
            exit;
            
        case 'reject_user':
            $input = json_decode(file_get_contents('php://input'), true);
            $userId = $input['user_id'] ?? null;
            $reason = $input['reason'] ?? null;
            
            if (!$userId || !$reason) {
                echo json_encode([
                    'success' => false,
                    'notification' => [
                        'type' => 'error',
                        'message' => 'User ID and rejection reason are required'
                    ]
                ]);
                exit;
            }
            
            $result = $adminService->rejectUser($userId, $reason);
            echo json_encode($result);
            exit;
            
        default:
            echo json_encode([
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Invalid action'
                ]
            ]);
            exit;
    }
}

// Include header
include __DIR__ . '/includes/admin-header.php';
?>

<!-- Main User Management Content -->
<main class="p-8">
    <div class="max-w-7xl mx-auto">
        <!-- Page Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800">User Management</h1>
            <p class="text-gray-600 mt-2">Manage customer users, approvals, and permissions</p>
        </div>

        <!-- Tabs -->
        <div class="bg-white rounded-lg shadow">
            <div class="border-b border-gray-200">
                <nav class="-mb-px flex" role="tablist">
                    <a href="?page=customer_users&tab=pending" 
                       class="<?php echo $activeTab === 'pending' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?> 
                              whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm transition-colors duration-200"
                       role="tab"
                       aria-selected="<?php echo $activeTab === 'pending' ? 'true' : 'false'; ?>">
                        <i class="fas fa-clock mr-2"></i>
                        Pending Approval
                        <span id="pendingCount" class="ml-2 bg-yellow-100 text-yellow-800 text-xs font-semibold px-2 py-0.5 rounded-full">0</span>
                    </a>
                    <a href="?page=customer_users&tab=active" 
                       class="<?php echo $activeTab === 'active' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?> 
                              whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm transition-colors duration-200"
                       role="tab"
                       aria-selected="<?php echo $activeTab === 'active' ? 'true' : 'false'; ?>">
                        <i class="fas fa-users mr-2"></i>
                        Active Users
                        <span id="activeCount" class="ml-2 bg-green-100 text-green-800 text-xs font-semibold px-2 py-0.5 rounded-full">0</span>
                    </a>
                    <a href="?page=customer_users&tab=rejected" 
                       class="<?php echo $activeTab === 'rejected' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?> 
                              whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm transition-colors duration-200"
                       role="tab"
                       aria-selected="<?php echo $activeTab === 'rejected' ? 'true' : 'false'; ?>">
                        <i class="fas fa-user-slash mr-2"></i>
                        Rejected Users
                    </a>
                </nav>
            </div>

            <!-- Tab Content -->
            <div class="p-6" role="tabpanel">
                <?php if ($activeTab === 'pending'): ?>
                    <!-- Pending Users Tab -->
                    <?php include __DIR__ . '/../templates/admin/customer-users/pending-approval-table.php'; ?>

                <?php elseif ($activeTab === 'active'): ?>
                    <!-- Active Users Tab -->
                    <?php include __DIR__ . '/../templates/admin/customer-users/active-users-table.php'; ?>

                <?php elseif ($activeTab === 'rejected'): ?>
                    <!-- Rejected Users Tab -->
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-user-slash text-5xl mb-4"></i>
                        <p>Rejected users functionality coming soon...</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<!-- Include Modals -->
<?php include __DIR__ . '/../templates/admin/customer-users/modals.php'; ?>

<!-- Include JavaScript files -->
<script src="/dev/assets/js/admin/admin.js"></script>
<script src="/dev/assets/js/admin/customer-users.js"></script>
<script>
// Initialize Customer Users module with PHP data
CustomerUsers.init({
    activeTab: '<?php echo $activeTab; ?>'
});
</script>

<?php include __DIR__ . '/includes/admin-footer.php'; ?>