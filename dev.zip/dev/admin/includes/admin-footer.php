<?php
// filepath: dev/admin/includes/admin-footer.php
?>
            </main>
        </div>
    </div>
    
    <!-- Toast Notification Container -->
    <div id="toastContainer" class="fixed bottom-4 right-4 z-50 space-y-2"></div>
    
    <!-- Notification Dropdown (Hidden by default, positioned dynamically) -->
    <div id="notificationDropdown" class="fixed bg-white border border-gray-200 rounded-lg shadow-xl hidden z-50 w-96 max-h-96 overflow-hidden">
        <div class="p-4 border-b border-gray-200">
            <h3 class="text-lg font-semibold text-gray-900">Notifications</h3>
        </div>
        <div id="notificationList" class="overflow-y-auto max-h-80">
            <!-- Notifications will be populated here -->
            <div class="p-8 text-center text-gray-500">
                <i class="fas fa-bell-slash text-4xl mb-2"></i>
                <p>No new notifications</p>
            </div>
        </div>
        <div class="p-3 border-t border-gray-200 bg-gray-50">
            <button class="text-sm text-blue-600 hover:text-blue-700 font-medium">Mark all as read</button>
        </div>
    </div>
    
    <script>
        // Global search functionality
        const globalSearch = document.getElementById('globalSearch');
        const searchResults = document.getElementById('searchResults');
        
        if (globalSearch && searchResults) {
            globalSearch.addEventListener('input', debounce(function() {
                if (this.value.length > 2) {
                    // Perform search (implement API call here)
                    searchResults.classList.remove('hidden');
                } else {
                    searchResults.classList.add('hidden');
                }
            }, 300));
            
            // Click outside to close search results
            document.addEventListener('click', function(e) {
                if (!globalSearch.contains(e.target) && !searchResults.contains(e.target)) {
                    searchResults.classList.add('hidden');
                }
            });
        }
        
        // Notification dropdown functionality
        const notificationBtn = document.getElementById('notificationBtn');
        const notificationDropdown = document.getElementById('notificationDropdown');
        const notificationBadge = document.getElementById('notificationBadge');
        const pendingBadge = document.getElementById('pendingBadge');
        
        if (notificationBtn && notificationDropdown) {
            notificationBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                
                // Position dropdown below the notification button
                const rect = notificationBtn.getBoundingClientRect();
                notificationDropdown.style.top = rect.bottom + 10 + 'px';
                notificationDropdown.style.right = window.innerWidth - rect.right + 'px';
                
                // Toggle dropdown
                notificationDropdown.classList.toggle('hidden');
                
                // Load notifications if opening (only if endpoint exists)
                if (!notificationDropdown.classList.contains('hidden')) {
                    // Comment out for now until notification endpoint is implemented
                    // loadNotifications();
                }
            });
            
            // Click outside to close notification dropdown
            document.addEventListener('click', function(e) {
                if (!notificationBtn.contains(e.target) && !notificationDropdown.contains(e.target)) {
                    notificationDropdown.classList.add('hidden');
                }
            });
        }
        
        // Load notifications (commented out until endpoint exists)
        /*
        function loadNotifications() {
            fetch('/dev/api/admin/notifications.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.notifications.length > 0) {
                        updateNotificationUI(data.notifications, data.unread_count);
                    }
                })
                .catch(error => console.error('Error loading notifications:', error));
        }
        */
        
        // Update notification UI
        function updateNotificationUI(notifications, unreadCount) {
            const notificationList = document.getElementById('notificationList');
            
            if (!notificationList || notifications.length === 0) {
                return;
            }
            
            // Update badges
            if (unreadCount > 0 && notificationBadge) {
                notificationBadge.textContent = unreadCount;
                notificationBadge.classList.remove('hidden');
                
                // Update pending users badge if applicable
                const pendingUsers = notifications.filter(n => n.type === 'pending_user').length;
                if (pendingUsers > 0 && pendingBadge) {
                    pendingBadge.textContent = pendingUsers;
                    pendingBadge.classList.remove('hidden');
                }
            }
            
            // Build notification HTML
            let html = '';
            notifications.forEach(notification => {
                const icon = getNotificationIcon(notification.type);
                const timeAgo = formatTimeAgo(notification.created_at);
                
                html += `
                    <div class="p-4 hover:bg-gray-50 border-b border-gray-100 cursor-pointer ${notification.read ? '' : 'bg-blue-50'}">
                        <div class="flex items-start space-x-3">
                            <div class="flex-shrink-0">
                                <div class="w-10 h-10 rounded-full flex items-center justify-center ${notification.read ? 'bg-gray-100' : 'bg-blue-100'}">
                                    <i class="${icon} ${notification.read ? 'text-gray-500' : 'text-blue-600'}"></i>
                                </div>
                            </div>
                            <div class="flex-1">
                                <p class="text-sm font-medium text-gray-900">${notification.title}</p>
                                <p class="text-sm text-gray-500 mt-1">${notification.message}</p>
                                <p class="text-xs text-gray-400 mt-2">${timeAgo}</p>
                            </div>
                            ${notification.action_url ? `
                                <a href="${notification.action_url}" class="text-blue-600 hover:text-blue-700 text-sm font-medium">
                                    View →
                                </a>
                            ` : ''}
                        </div>
                    </div>
                `;
            });
            
            notificationList.innerHTML = html;
        }
        
        // Helper functions
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
        
        function getNotificationIcon(type) {
            const icons = {
                'pending_user': 'fas fa-user-clock',
                'new_user': 'fas fa-user-plus',
                'system_alert': 'fas fa-exclamation-triangle',
                'customer_update': 'fas fa-building',
                'general': 'fas fa-info-circle'
            };
            return icons[type] || icons.general;
        }
        
        function formatTimeAgo(datetime) {
            const date = new Date(datetime);
            const now = new Date();
            const seconds = Math.floor((now - date) / 1000);
            
            if (seconds < 60) return 'Just now';
            if (seconds < 3600) return Math.floor(seconds / 60) + ' minutes ago';
            if (seconds < 86400) return Math.floor(seconds / 3600) + ' hours ago';
            if (seconds < 604800) return Math.floor(seconds / 86400) + ' days ago';
            
            return date.toLocaleDateString();
        }
        
        // Check for notifications on page load (commented out until endpoint exists)
        /*
        window.addEventListener('load', function() {
            loadNotifications();
            
            // Refresh notifications every 30 seconds
            setInterval(loadNotifications, 30000);
        });
        */
    </script>
</body>
</html>