<?php
// filepath: dev/admin/includes/admin-header.php

// Ensure user is authenticated
if (!isset($user)) {
    header('Location: /dev/login.php');
    exit;
}

// Get current page for active navigation
$currentPage = $_GET['page'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Custom scrollbar styling */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        ::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 3px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        /* Smooth transitions */
        .nav-link {
            transition: all 0.2s ease;
        }
        /* Notification animation */
        @keyframes pulse {
            0% {
                transform: scale(1);
                opacity: 1;
            }
            50% {
                transform: scale(1.1);
                opacity: 0.8;
            }
            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
        .notification-pulse {
            animation: pulse 2s infinite;
        }
    </style>
</head>
<body class="bg-gray-50 font-sans antialiased">
    <div class="flex h-screen overflow-hidden">
        <!-- A. Main Navigation Sidebar (Left, Fixed) -->
        <nav class="w-64 bg-white shadow-lg border-r border-gray-200 flex flex-col h-full">
            <!-- Logo Section -->
            <div class="p-6 border-b border-gray-200">
                <div class="flex items-center space-x-3">
                    <img src="/assets/img/dannyslogo.png" alt="Logo" class="h-10 w-10 rounded">
                    <div>
                        <h2 class="text-lg font-bold text-gray-900">Admin Panel</h2>
                        <p class="text-xs text-gray-500">Management Console</p>
                    </div>
                </div>
            </div>
            
            <!-- Navigation Menu -->
            <div class="flex-1 overflow-y-auto py-4 px-3">
                <nav class="space-y-1">
                    <a href="/dev/admin/?page=dashboard" 
                       class="nav-link flex items-center px-4 py-3 text-sm font-medium rounded-lg <?= $currentPage === 'dashboard' ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-gray-700 hover:bg-gray-50' ?>">
                        <i class="fas fa-home w-5 text-center mr-3 <?= $currentPage === 'dashboard' ? 'text-blue-600' : 'text-gray-400' ?>"></i>
                        <span>Dashboard</span>
                        <?php if ($currentPage === 'dashboard'): ?>
                            <div class="ml-auto w-1 h-6 bg-blue-600 rounded-full"></div>
                        <?php endif; ?>
                    </a>
                    
                    <a href="/dev/admin/?page=customer_users" 
                       class="<?php echo $currentPage === 'customer_users' ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-700' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'; ?> nav-link group flex items-center px-2 py-2 text-sm font-medium">
                        <i class="fas fa-users mr-3 flex-shrink-0 h-6 w-6"></i>
                        User Management
                    </a>
                    
                    <a href="/dev/admin/?page=customers" 
                       class="nav-link flex items-center px-4 py-3 text-sm font-medium rounded-lg <?= $currentPage === 'customers' ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-gray-700 hover:bg-gray-50' ?>">
                        <i class="fas fa-building w-5 text-center mr-3 <?= $currentPage === 'customers' ? 'text-blue-600' : 'text-gray-400' ?>"></i>
                        <span>Customer Management</span>
                        <?php if ($currentPage === 'customers'): ?>
                            <div class="ml-auto w-1 h-6 bg-blue-600 rounded-full"></div>
                        <?php endif; ?>
                    </a>
                    
                    <a href="/dev/admin/?page=system-health" 
                       class="nav-link flex items-center px-4 py-3 text-sm font-medium rounded-lg <?= $currentPage === 'system-health' ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-gray-700 hover:bg-gray-50' ?>">
                        <i class="fas fa-server w-5 text-center mr-3 <?= $currentPage === 'system-health' ? 'text-blue-600' : 'text-gray-400' ?>"></i>
                        <span>System Health</span>
                        <?php if ($currentPage === 'system-health'): ?>
                            <div class="ml-auto w-1 h-6 bg-blue-600 rounded-full"></div>
                        <?php endif; ?>
                    </a>
                </nav>
            </div>
            
            <!-- User Profile Section (Bottom) -->
            <div class="border-t border-gray-200 p-4">
                <div class="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 cursor-pointer group">
                    <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-sm">
                        <span class="text-white font-semibold text-sm">
                            <?= strtoupper(substr($user['name'] ?? 'A', 0, 1)) ?>
                        </span>
                    </div>
                    <div class="flex-1">
                        <p class="text-sm font-medium text-gray-900"><?= htmlspecialchars($user['name'] ?? 'Admin') ?></p>
                        <p class="text-xs text-gray-500">
                            <?= htmlspecialchars($user['user_type'] ?? 'platform_user') ?> • <?= htmlspecialchars($user['role'] ?? 'Administrator') ?>
                        </p>
                    </div>
                    <a href="/dev/logout.php" 
                       class="text-gray-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                       title="Logout">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Main Content Wrapper -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- B. Top Header Bar (Top, Fixed) -->
            <header class="bg-white shadow-sm border-b border-gray-200 z-10">
                <div class="px-6 py-4 flex items-center justify-between">
                    <!-- Global Search Bar (Left/Center) -->
                    <div class="flex-1 max-w-2xl">
                        <div class="relative">
                            <input type="text" 
                                   id="globalSearch"
                                   placeholder="Search users, customers, or any data..." 
                                   class="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:bg-white transition-colors">
                            <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                            <!-- Search Results Dropdown (Hidden by default) -->
                            <div id="searchResults" class="absolute top-full mt-2 w-full bg-white border border-gray-200 rounded-lg shadow-lg hidden max-h-96 overflow-y-auto">
                                <!-- Search results will be populated here -->
                            </div>
                        </div>
                    </div>
                    
                    <!-- Right Side: Notification Center -->
                    <div class="flex items-center space-x-4 ml-6">
                        <!-- Notifications -->
                        <button id="notificationBtn" class="relative p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                            <i class="fas fa-bell text-xl"></i>
                            <span id="notificationBadge" class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center hidden notification-pulse">0</span>
                        </button>
                        
                        <!-- Quick Actions -->
                        <div class="relative">
                            <button class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="Quick Actions">
                                <i class="fas fa-plus-circle text-xl"></i>
                            </button>
                            <!-- Quick Actions Dropdown (Hidden by default) -->
                            <div class="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg hidden">
                                <a href="/dev/admin/?page=users&action=add" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                                    <i class="fas fa-user-plus mr-2"></i>Add User
                                </a>
                                <a href="/dev/admin/?page=customers&action=add" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                                    <i class="fas fa-building mr-2"></i>Add Customer
                                </a>
                            </div>
                        </div>
                        
                        <!-- Settings -->
                        <button class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="Settings">
                            <i class="fas fa-cog text-xl"></i>
                        </button>
                    </div>
                </div>
            </header>
            
            <!-- C. Main Content Area (Center, Dynamic) -->
            <main class="flex-1 overflow-y-auto bg-gray-50">
                <div class="p-6">
                    <!-- Dynamic content will be loaded here -->