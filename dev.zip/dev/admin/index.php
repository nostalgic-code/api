<?php
// filepath: dev/admin/index.php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../src/Middleware/AdminMiddleware.php';

// Check if user is a platform admin
$adminMiddleware = new AdminMiddleware();
$adminMiddleware->handle();

// Get user data
$sessionManager = new SessionManager();
$user = $sessionManager->getUser();

// Default to dashboard if no specific page is requested
$page = $_GET['page'] ?? 'dashboard';

// Define allowed pages
$allowedPages = ['dashboard', 'customer_users', 'customers', 'system-health'];

// Validate requested page
if (!in_array($page, $allowedPages)) {
    $page = 'dashboard';
}

// Load the appropriate page
switch ($page) {
    case 'customer_users':
        require_once __DIR__ . '/customer_users.php';
        break;
    case 'customers':
        require_once __DIR__ . '/customers.php';
        break;
    case 'system-health':
        require_once __DIR__ . '/system-health.php';
        break;
    default:
        require_once __DIR__ . '/dashboard.php';
        break;
}