<?php
?>
<!-- User Distribution Chart -->
<div class="bg-white rounded-lg shadow-sm">
    <div class="px-6 py-4 border-b border-gray-200">
        <h3 class="text-lg font-semibold text-gray-900">User Distribution by Role</h3>
    </div>
    <div class="p-6">
        <canvas id="userRoleChart" class="w-full" style="max-height: 300px;"></canvas>
    </div>
</div>