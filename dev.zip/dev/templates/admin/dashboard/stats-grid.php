<?php
// Get stats data from the dashboard - ensure we have the correct data structure
$stats = $dashboardData['stats'] ?? [];

// Ensure all required fields have default values
$stats = array_merge([
    'total_customers' => 0,
    'total_users' => 0,
    'pending_approvals' => 0,
    'total_depots' => 0,
    'active_users' => 0,
    'rejected_users' => 0,
    'customer_breakdown' => [],
    'user_breakdown' => [],
    'permission_codes' => 0
], $stats);
?>

<!-- Statistics Cards Grid -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="stats-grid">
    <!-- Total Customers Card (Expandable) -->
    <div class="bg-white rounded-lg shadow-sm p-6 relative overflow-hidden stat-card expandable-card" data-stat-id="total-customers">
        <div class="flex items-center justify-between cursor-pointer" onclick="toggleCardExpansion('total-customers')">
            <div>
                <p class="text-sm font-medium text-gray-600">Total Customers</p>
                <p class="text-2xl font-bold text-gray-900 mt-1">
                    <span class="stat-value"><?php echo number_format($stats['total_customers']); ?></span>
                </p>
                <p class="text-xs text-gray-500 mt-1">
                    <span class="text-green-600">
                        <i class="fas fa-arrow-up"></i> <?php echo number_format($stats['customer_breakdown']['approved'] ?? 0); ?> approved
                    </span>
                </p>
            </div>
            <div class="text-blue-500 opacity-20">
                <i class="fas fa-building text-5xl"></i>
            </div>
            <div class="absolute top-2 right-2 text-gray-400 expand-icon">
                <i class="fas fa-chevron-down text-xs"></i>
            </div>
        </div>
        
        <!-- Expandable Content -->
        <div class="card-expansion hidden mt-4 pt-4 border-t border-gray-200">
            <div class="space-y-2">
                <?php 
                $customerBreakdown = $stats['customer_breakdown'] ?? [];
                $customerStatuses = [
                    'approved' => ['label' => 'Approved', 'color' => 'text-green-600', 'bg' => 'bg-green-100'],
                    'pending' => ['label' => 'Pending', 'color' => 'text-yellow-600', 'bg' => 'bg-yellow-100'],
                    'suspended' => ['label' => 'Suspended', 'color' => 'text-red-600', 'bg' => 'bg-red-100']
                ];
                ?>
                <?php foreach ($customerStatuses as $status => $config): ?>
                    <div class="flex items-center justify-between py-1">
                        <span class="text-xs font-medium text-gray-600"><?php echo $config['label']; ?></span>
                        <span class="<?php echo $config['color']; ?> <?php echo $config['bg']; ?> px-2 py-0.5 rounded-full text-xs font-semibold customer-stat" data-status="<?php echo $status; ?>">
                            <?php echo number_format($customerBreakdown[$status] ?? 0); ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- Total Users Card (Expandable) -->
    <div class="bg-white rounded-lg shadow-sm p-6 relative overflow-hidden stat-card expandable-card" data-stat-id="total-users">
        <div class="flex items-center justify-between cursor-pointer" onclick="toggleCardExpansion('total-users')">
            <div>
                <p class="text-sm font-medium text-gray-600">Total Users</p>
                <p class="text-2xl font-bold text-gray-900 mt-1">
                    <span class="stat-value"><?php echo number_format($stats['total_users']); ?></span>
                </p>
                <p class="text-xs text-gray-500 mt-1">
                    <span class="stat-active"><?php echo number_format($stats['active_users']); ?></span> active
                </p>
            </div>
            <div class="text-green-500 opacity-20">
                <i class="fas fa-users text-5xl"></i>
            </div>
            <div class="absolute top-2 right-2 text-gray-400 expand-icon">
                <i class="fas fa-chevron-down text-xs"></i>
            </div>
        </div>
        
        <!-- Expandable Content -->
        <div class="card-expansion hidden mt-4 pt-4 border-t border-gray-200">
            <div class="space-y-2">
                <?php 
                $userBreakdown = $stats['user_breakdown'] ?? [];
                $userTypes = [
                    'customer_users' => ['label' => 'Customer Users', 'color' => 'text-blue-600', 'bg' => 'bg-blue-100'],
                    'platform_users' => ['label' => 'Platform Users', 'color' => 'text-purple-600', 'bg' => 'bg-purple-100'],
                    'admins' => ['label' => 'Admin Users', 'color' => 'text-indigo-600', 'bg' => 'bg-indigo-100']
                ];
                $userStatuses = [
                    'approved' => ['label' => 'Approved', 'color' => 'text-green-600', 'bg' => 'bg-green-100'],
                    'pending' => ['label' => 'Pending', 'color' => 'text-yellow-600', 'bg' => 'bg-yellow-100'],
                    'rejected' => ['label' => 'Rejected', 'color' => 'text-red-600', 'bg' => 'bg-red-100']
                ];
                ?>
                <!-- User Types -->
                <div class="text-xs font-semibold text-gray-700 mb-1">By Type:</div>
                <?php foreach ($userTypes as $type => $config): ?>
                    <?php if (isset($userBreakdown[$type])): ?>
                    <div class="flex items-center justify-between py-1 pl-2">
                        <span class="text-xs font-medium text-gray-600"><?php echo $config['label']; ?></span>
                        <span class="<?php echo $config['color']; ?> <?php echo $config['bg']; ?> px-2 py-0.5 rounded-full text-xs font-semibold user-stat" data-type="<?php echo $type; ?>">
                            <?php echo number_format($userBreakdown[$type]); ?>
                        </span>
                    </div>
                    <?php endif; ?>
                <?php endforeach; ?>
                
                <!-- User Statuses -->
                <div class="text-xs font-semibold text-gray-700 mb-1 mt-2">By Status:</div>
                <?php foreach ($userStatuses as $status => $config): ?>
                    <?php if (isset($userBreakdown[$status])): ?>
                    <div class="flex items-center justify-between py-1 pl-2">
                        <span class="text-xs font-medium text-gray-600"><?php echo $config['label']; ?></span>
                        <span class="<?php echo $config['color']; ?> <?php echo $config['bg']; ?> px-2 py-0.5 rounded-full text-xs font-semibold user-stat" data-status="<?php echo $status; ?>">
                            <?php echo number_format($userBreakdown[$status]); ?>
                        </span>
                    </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- Pending Approvals Card -->
    <div class="bg-white rounded-lg shadow-sm p-6 relative overflow-hidden border-l-4 border-yellow-400 stat-card" data-stat-id="pending-approvals">
        <?php if ($stats['pending_approvals'] > 0): ?>
            <div class="absolute top-2 right-2 stat-badge">
                <span class="bg-red-500 text-white text-xs px-2 py-1 rounded-full">Action Required</span>
            </div>
        <?php endif; ?>
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-600">Pending Approvals</p>
                <p class="text-2xl font-bold text-yellow-600 mt-1">
                    <span class="stat-value"><?php echo number_format($stats['pending_approvals']); ?></span>
                </p>
                <?php if ($stats['pending_approvals'] > 0): ?>
                    <a href="/dev/admin/?page=customer_users&tab=pending" class="text-xs text-yellow-600 mt-1 inline-flex items-center hover:text-yellow-700">
                        <i class="fas fa-arrow-right-circle mr-1"></i> Review now
                    </a>
                <?php else: ?>
                    <p class="text-xs text-gray-500 mt-1">All users approved</p>
                <?php endif; ?>
            </div>
            <div class="text-yellow-500 opacity-20">
                <i class="fas fa-clock text-5xl"></i>
            </div>
        </div>
    </div>
    
    <!-- Total Depots Card -->
    <div class="bg-white rounded-lg shadow-sm p-6 relative overflow-hidden stat-card" data-stat-id="total-depots">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-600">Total Depots</p>
                <p class="text-2xl font-bold text-gray-900 mt-1">
                    <span class="stat-value"><?php echo number_format($stats['total_depots']); ?></span>
                </p>
                <p class="text-xs text-gray-500 mt-1">
                    Across all customers
                </p>
            </div>
            <div class="text-purple-500 opacity-20">
                <i class="fas fa-map-marker-alt text-5xl"></i>
            </div>
        </div>
    </div>
</div>

<!-- Additional Stats Row -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
    <!-- Active Users Card -->
    <div class="bg-white rounded-lg shadow-sm p-6 relative overflow-hidden stat-card" data-stat-id="active-users">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-600">Active Users</p>
                <p class="text-2xl font-bold text-green-600 mt-1">
                    <span class="stat-value"><?php echo number_format($stats['active_users']); ?></span>
                </p>
                <p class="text-xs text-gray-500 mt-1">
                    Currently active in system
                </p>
            </div>
            <div class="text-green-500 opacity-20">
                <i class="fas fa-check-circle text-5xl"></i>
            </div>
        </div>
    </div>
    
    <!-- Rejected Users Card -->
    <div class="bg-white rounded-lg shadow-sm p-6 relative overflow-hidden stat-card" data-stat-id="rejected-users">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-600">Rejected Users</p>
                <p class="text-2xl font-bold text-red-600 mt-1">
                    <span class="stat-value"><?php echo number_format($stats['rejected_users']); ?></span>
                </p>
                <p class="text-xs text-gray-500 mt-1">
                    Registration rejected
                </p>
            </div>
            <div class="text-red-500 opacity-20">
                <i class="fas fa-times-circle text-5xl"></i>
            </div>
        </div>
    </div>
    
    <!-- Permission Codes Card -->
    <div class="bg-white rounded-lg shadow-sm p-6 relative overflow-hidden stat-card" data-stat-id="permission-codes">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-600">Permission Codes</p>
                <p class="text-2xl font-bold text-indigo-600 mt-1">
                    <span class="stat-value"><?php echo number_format($stats['permission_codes']); ?></span>
                </p>
                <p class="text-xs text-gray-500 mt-1">
                    Access codes issued
                </p>
            </div>
            <div class="text-indigo-500 opacity-20">
                <i class="fas fa-key text-5xl"></i>
            </div>
        </div>
    </div>
</div>

<style>
.expandable-card {
    transition: all 0.3s ease;
}

.expandable-card.expanded {
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
}

.expand-icon {
    transition: transform 0.3s ease;
}

.expandable-card.expanded .expand-icon i {
    transform: rotate(180deg);
}

.card-expansion {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
}

.card-expansion:not(.hidden) {
    max-height: 300px;
}

.expandable-card > div:first-child:hover {
    background-color: rgba(0, 0, 0, 0.02);
    margin: -0.5rem;
    padding: 0.5rem;
    border-radius: 0.375rem;
}
</style>