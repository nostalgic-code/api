<?php
?>
<!-- Recent Activity Feed -->
<div class="bg-white rounded-lg shadow-sm">
    <div class="px-6 py-4 border-b border-gray-200">
        <h3 class="text-lg font-semibold text-gray-900">Recent Activity</h3>
    </div>
    <div class="divide-y divide-gray-200">
        <!-- Activity items will be loaded dynamically -->
        <div id="activityFeed" class="divide-y divide-gray-200">
            <!-- Mock activities for now -->
            <div class="px-6 py-4 hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <span class="inline-flex items-center justify-center h-8 w-8 rounded-full bg-green-100">
                            <i class="fas fa-user-check text-green-600 text-sm"></i>
                        </span>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-gray-900">
                            <span class="font-medium">User Approved:</span> john.doe@company.com
                        </p>
                        <p class="text-xs text-gray-500 mt-1">2 hours ago</p>
                    </div>
                </div>
            </div>
            
            <div class="px-6 py-4 hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <span class="inline-flex items-center justify-center h-8 w-8 rounded-full bg-blue-100">
                            <i class="fas fa-building text-blue-600 text-sm"></i>
                        </span>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-gray-900">
                            <span class="font-medium">New Customer:</span> ABC Auto Parts registered
                        </p>
                        <p class="text-xs text-gray-500 mt-1">5 hours ago</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="px-6 py-3 bg-gray-50 text-center">
        <a href="#" class="text-sm text-blue-600 hover:text-blue-700 font-medium">View All Activity</a>
    </div>
</div>