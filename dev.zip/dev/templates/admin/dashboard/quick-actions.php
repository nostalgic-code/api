<?php
?>
<!-- Quick Actions -->
<div class="bg-white rounded-lg shadow-sm">
    <div class="px-6 py-4 border-b border-gray-200">
        <h3 class="text-lg font-semibold text-gray-900">Quick Actions</h3>
    </div>
    <div class="p-6 space-y-3">
        <a href="/dev/admin/?page=customer_users&tab=pending" class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <div class="flex items-center">
                <i class="fas fa-user-clock text-yellow-600 mr-3"></i>
                <span class="text-sm font-medium text-gray-900">Review Pending Users</span>
            </div>
            <i class="fas fa-arrow-right text-gray-400"></i>
        </a>
        
        <a href="/dev/admin/?page=customers" class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <div class="flex items-center">
                <i class="fas fa-building text-blue-600 mr-3"></i>
                <span class="text-sm font-medium text-gray-900">Manage Customers</span>
            </div>
            <i class="fas fa-arrow-right text-gray-400"></i>
        </a>
        
        <a href="/dev/admin/?page=system-health" class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <div class="flex items-center">
                <i class="fas fa-heartbeat text-green-600 mr-3"></i>
                <span class="text-sm font-medium text-gray-900">Check System Health</span>
            </div>
            <i class="fas fa-arrow-right text-gray-400"></i>
        </a>
    </div>
</div>