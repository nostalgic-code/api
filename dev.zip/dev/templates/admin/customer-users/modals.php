<?php
/**
 * Customer Users Management Modals
 * 
 * This file contains all modal dialogs used in the customer users management page
 */
?>

<!-- Approve User Modal -->
<div id="approveModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-bold text-gray-900">Approve User</h3>
            <button onclick="CustomerUsers.closeApproveModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div id="approveModalContent">
            <!-- User details will be loaded here dynamically -->
        </div>
        
        <div class="mt-4 flex justify-end space-x-3">
            <button onclick="CustomerUsers.closeApproveModal()" 
                    class="px-4 py-2 bg-gray-300 text-gray-800 text-base font-medium rounded-md shadow-sm hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 transition-colors duration-200">
                Cancel
            </button>
            <button onclick="CustomerUsers.confirmApprove()" 
                    class="px-4 py-2 bg-green-600 text-white text-base font-medium rounded-md shadow-sm hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 transition-colors duration-200">
                <i class="fas fa-check mr-2"></i>Approve
            </button>
        </div>
    </div>
</div>

<!-- Reject User Modal -->
<div id="rejectModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-bold text-gray-900">Reject User</h3>
            <button onclick="CustomerUsers.closeRejectModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div id="rejectModalContent">
            <!-- User details will be loaded here dynamically -->
        </div>
        
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">
                Rejection Reason <span class="text-red-500">*</span>
            </label>
            <textarea id="rejectionReason" 
                      rows="3" 
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
                      placeholder="Please provide a reason for rejection..."></textarea>
            <p class="mt-1 text-sm text-gray-500">This reason will be sent to the user via email.</p>
        </div>
        
        <div class="flex justify-end space-x-3">
            <button onclick="CustomerUsers.closeRejectModal()" 
                    class="px-4 py-2 bg-gray-300 text-gray-800 text-base font-medium rounded-md shadow-sm hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 transition-colors duration-200">
                Cancel
            </button>
            <button onclick="CustomerUsers.confirmReject()" 
                    class="px-4 py-2 bg-red-600 text-white text-base font-medium rounded-md shadow-sm hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 transition-colors duration-200">
                <i class="fas fa-times mr-2"></i>Reject
            </button>
        </div>
    </div>
</div>

<!-- Success Modal (for confirmation messages) -->
<div id="successModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="text-center">
            <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 mb-4">
                <i class="fas fa-check text-green-600"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2" id="successModalTitle">Success!</h3>
            <p class="text-sm text-gray-500" id="successModalMessage">Operation completed successfully.</p>
            <div class="mt-4">
                <button onclick="document.getElementById('successModal').classList.add('hidden')" 
                        class="px-4 py-2 bg-green-600 text-white text-base font-medium rounded-md shadow-sm hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500">
                    OK
                </button>
            </div>
        </div>
    </div>
</div>