<?php
/**
 * Pending Approval Users Table Template
 * 
 * This template handles the display of pending user approvals
 */
?>

<div id="pendingUsersSection">
    <!-- Search and Filter Bar -->
    <div class="mb-6 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div class="flex-1 max-w-lg">
            <div class="relative">
                <input type="text" 
                       id="searchPending" 
                       placeholder="Search by name, email, or customer..." 
                       class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors duration-200"
                       aria-label="Search pending users">
                <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
            </div>
        </div>
        
        <div class="flex items-center gap-2">
            <!-- Filter Dropdown (future enhancement) -->
            <div class="relative hidden" id="filterDropdown">
                <button class="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors duration-200">
                    <i class="fas fa-filter mr-2"></i>Filter
                </button>
            </div>
            
            <!-- Refresh Button -->
            <button onclick="CustomerUsers.loadPendingUsers()" 
                    class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-gray-300"
                    aria-label="Refresh pending users list">
                <i class="fas fa-sync-alt mr-2"></i>Refresh
            </button>
        </div>
    </div>

    <!-- Pending Users Table -->
    <div class="overflow-x-auto shadow-sm border border-gray-200 rounded-lg">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        User Name
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Email
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Customer
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Role Requested
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date Registered
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                    </th>
                </tr>
            </thead>
            <tbody id="pendingUsersTableBody" class="bg-white divide-y divide-gray-200">
                <!-- Pending users will be loaded here dynamically -->
            </tbody>
        </table>
    </div>

    <!-- Loading State -->
    <div id="loadingState" class="hidden">
        <div class="text-center py-12">
            <i class="fas fa-spinner fa-spin text-4xl text-blue-500 mb-4"></i>
            <p class="text-gray-600 text-lg">Loading pending users...</p>
        </div>
    </div>

    <!-- Empty State -->
    <div id="emptyState" class="hidden">
        <div class="text-center py-12">
            <div class="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                <i class="fas fa-check-circle text-3xl text-green-500"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">All caught up!</h3>
            <p class="text-gray-500">No pending user approvals at the moment.</p>
        </div>
    </div>

    <!-- Error State -->
    <div id="errorState" class="hidden">
        <div class="text-center py-12">
            <div class="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-4">
                <i class="fas fa-exclamation-triangle text-3xl text-red-500"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">Error loading users</h3>
            <p class="text-gray-500 mb-4">Unable to load pending users. Please try again.</p>
            <button onclick="CustomerUsers.loadPendingUsers()" 
                    class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors duration-200">
                <i class="fas fa-redo mr-2"></i>Try Again
            </button>
        </div>
    </div>
</div>