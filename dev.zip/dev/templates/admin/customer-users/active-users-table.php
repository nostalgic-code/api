<?php
/**
 * Active Users Table Template
 * 
 * This template handles the display of active (approved) users
 */
?>

<div id="activeUsersSection">
    <!-- Search and Filter Bar -->
    <div class="mb-6 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div class="flex-1 max-w-lg">
            <div class="relative">
                <input type="text" 
                       id="searchActive" 
                       placeholder="Search by name, email, or customer..." 
                       class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors duration-200"
                       aria-label="Search active users">
                <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
            </div>
        </div>
        
        <div class="flex items-center gap-2">
            <!-- Role Filter Dropdown -->
            <div class="relative">
                <select id="roleFilter" 
                        class="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors duration-200">
                    <option value="">All Roles</option>
                    <option value="owner">Owner</option>
                    <option value="staff">Staff</option>
                    <option value="viewer">Viewer</option>
                </select>
            </div>
            
            <!-- Refresh Button -->
            <button onclick="CustomerUsers.loadActiveUsers()" 
                    class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-gray-300"
                    aria-label="Refresh active users list">
                <i class="fas fa-sync-alt mr-2"></i>Refresh
            </button>
        </div>
    </div>

    <!-- Active Users Table -->
    <div class="shadow-sm border border-gray-200 rounded-lg overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200 table-fixed">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="w-1/4 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        User Name
                    </th>
                    <th scope="col" class="w-1/5 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Email
                    </th>
                    <th scope="col" class="w-1/5 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Customer
                    </th>
                    <th scope="col" class="w-1/10 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Role
                    </th>
                    <th scope="col" class="w-1/6 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Depot Access
                    </th>
                    <th scope="col" class="w-1/6 px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                    </th>
                </tr>
            </thead>
            <tbody id="activeUsersTableBody" class="bg-white divide-y divide-gray-200">
                <!-- Active users will be loaded here dynamically -->
            </tbody>
        </table>
    </div>

    <!-- Loading State -->
    <div id="activeLoadingState" class="hidden">
        <div class="text-center py-12">
            <i class="fas fa-spinner fa-spin text-4xl text-blue-500 mb-4"></i>
            <p class="text-gray-600 text-lg">Loading active users...</p>
        </div>
    </div>

    <!-- Empty State -->
    <div id="activeEmptyState" class="hidden">
        <div class="text-center py-12">
            <div class="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
                <i class="fas fa-users-slash text-3xl text-gray-400"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">No active users found</h3>
            <p class="text-gray-500">No active users match your search criteria.</p>
        </div>
    </div>

    <!-- Error State -->
    <div id="activeErrorState" class="hidden">
        <div class="text-center py-12">
            <div class="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-4">
                <i class="fas fa-exclamation-triangle text-3xl text-red-500"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">Error loading users</h3>
            <p class="text-gray-500 mb-4">Unable to load active users. Please try again.</p>
            <button onclick="CustomerUsers.loadActiveUsers()" 
                    class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors duration-200">
                <i class="fas fa-redo mr-2"></i>Try Again
            </button>
        </div>
    </div>
</div>