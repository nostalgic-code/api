<?php
// filepath: dev/templates/auth/login-form.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/dev/assets/css/style.css">
</head>
<body class="bg-gradient-to-br from-blue-50 to-blue-100">
    <div class="min-h-screen flex items-center justify-center py-12">
        <div class="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-blue-100 p-8 relative">
            <div class="flex flex-col items-center mb-8">
                <img src="/assets/img/dannyslogo.png" alt="Danny's Auto Spares Logo" class="h-16 mb-2">
                <h2 class="text-2xl font-bold text-blue-800 mb-2">
                    Sign in to <?= APP_NAME ?>
                </h2>
                <p class="text-gray-500 text-sm">
                    Enter your phone number to receive a one-time password (OTP).
                </p>
            </div>
            
            <!-- Phone Form -->
            <form id="phoneForm" class="mt-8 space-y-6">
                <div class="mb-6">
                    <label for="phone" class="block text-blue-800 font-semibold mb-2">
                        Phone Number
                    </label>
                    <input
                        id="phone"
                        name="phone"
                        type="tel"
                        required
                        class="w-full px-4 py-3 border border-blue-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700 bg-blue-50 text-gray-800 transition"
                        placeholder="e.g. +27871234567"
                    >
                </div>
                
                <div>
                    <button
                        type="submit"
                        id="sendOtpBtn"
                        class="w-full py-3 bg-blue-800 hover:bg-blue-900 text-white font-bold rounded-lg shadow transition"
                    >
                        Send OTP
                    </button>
                </div>
                
                <div class="text-center mt-4">
                    <p class="text-gray-600 text-sm">
                        Don't have an account? 
                        <a href="/dev/register.php" class="text-blue-600 hover:text-blue-800 underline">
                            Create one
                        </a>
                    </p>
                </div>
            </form>
            
            <!-- OTP Form -->
            <form id="otpForm" class="hidden mt-8 border-t border-blue-100 pt-8 animate-fade-in">
                <div class="mb-4">
                    <label for="otp" class="block text-blue-800 font-semibold mb-2">
                        Enter OTP
                    </label>
                    <input
                        id="otp"
                        name="otp"
                        type="text"
                        maxlength="6"
                        required
                        class="w-full px-4 py-3 border border-blue-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700 text-center tracking-widest text-lg font-semibold bg-blue-50"
                        placeholder="000000"
                    >
                </div>
                
                <div id="timer" class="mt-2 mb-4 font-semibold text-red-600 text-center"></div>
                
                <div class="mb-4">
                    <button
                        type="submit"
                        id="verifyOtpBtn"
                        class="w-full py-3 bg-blue-800 hover:bg-blue-900 text-white font-bold rounded-lg shadow transition"
                    >
                        Verify OTP
                    </button>
                </div>
                
                <div class="text-center">
                    <button
                        type="button"
                        id="changePhoneBtn"
                        class="text-sm text-blue-600 hover:text-blue-800 underline"
                    >
                        Use different phone number
                    </button>
                </div>
            </form>
            
            <!-- Messages -->
            <div id="messageDiv" class="hidden mt-4 text-center">
                <p id="messageText" class="text-red-600 font-medium"></p>
            </div>
            
            <div class="mt-8 text-xs text-gray-400 text-center">
                &copy; <?= date('Y') ?> Danny's Auto Spares. All rights reserved.
            </div>
        </div>
    </div>
    
    <script src="/dev/assets/js/auth.js"></script>
    
    <style>
        @keyframes fade-in {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .animate-fade-in {
            animation: fade-in 0.3s ease-out;
        }
    </style>
</body>
</html>