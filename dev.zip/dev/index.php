<?php
// filepath: dev/index.php

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/src/Services/SessionManager.php';

// Initialize session manager
$sessionManager = new SessionManager();

// Check if user is authenticated
if ($sessionManager->isAuthenticated()) {
    // Route based on user type
    if ($sessionManager->isPlatformUser()) {
        header('Location: /dev/admin/');
        exit;
    } else {
        header('Location: /dev/home.php');
        exit;
    }
} else {
    // Redirect to login page if not authenticated
    header('Location: /dev/login.php');
    exit;
}