<?php
require_once __DIR__ . '/../Services/SessionManager.php';

class CustomerMiddleware {
    private SessionManager $sessionManager;
    
    public function __construct() {
        $this->sessionManager = new SessionManager();
    }
    
    public function requireCustomerAuth(): void {
        if (!$this->sessionManager->isAuthenticated()) {
            header('Location: /dev/login.php');
            exit;
        }
        
        if ($this->sessionManager->isPlatformUser()) {
            header('Location: /dev/admin/');
            exit;
        }
    }
    
    public function requireOwnerRole(): void {
        $this->requireCustomerAuth();
        
        $user = $this->sessionManager->get('user');
        if ($user['role'] !== 'owner') {
            header('Location: /dev/customer/products.php');
            exit;
        }
    }
    
    public function canPurchase(): bool {
        $user = $this->sessionManager->get('user');
        return in_array($user['role'], ['owner', 'staff']);
    }
    
    public function getUserRole(): string {
        $user = $this->sessionManager->get('user');
        return $user['role'] ?? 'viewer';
    }
}