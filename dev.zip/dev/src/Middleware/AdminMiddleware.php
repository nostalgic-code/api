<?php

require_once __DIR__ . '/../Services/SessionManager.php';
require_once __DIR__ . '/../Services/AuthService.php';

class AdminMiddleware {
    private SessionManager $sessionManager;
    private AuthService $authService;
    
    public function __construct() {
        $this->sessionManager = new SessionManager();
        $this->authService = new AuthService();
    }
    
    public function handle(): void {
        // First check basic authentication
        if (!$this->sessionManager->isAuthenticated()) {
            header('Location: /dev/login.php');
            exit;
        }
        
        // Validate session with backend
        if (!$this->authService->validateSession()) {
            header('Location: /dev/login.php');
            exit;
        }
        
        // Check if user is a platform user
        if (!$this->sessionManager->isPlatformUser()) {
            // Redirect customer users to their dashboard
            header('Location: /dev/home.php');
            exit;
        }
    }
    
    public function requireRole(string $role): void {
        $this->handle();
        
        $userRole = $this->sessionManager->getUserRole();
        if ($userRole !== $role) {
            header('HTTP/1.1 403 Forbidden');
            echo 'Access denied. Required role: ' . $role;
            exit;
        }
    }
}