<?php
// filepath: dev/src/Middleware/AuthMiddleware.php

require_once __DIR__ . '/../Services/AuthService.php';

class AuthMiddleware {
    private AuthService $authService;
    
    public function __construct() {
        $this->authService = new AuthService();
    }
    
    public function handle(): void {
        $this->authService->requireAuth();
    }
}