<?php
// filepath: dev/src/Services/CartService.php

require_once __DIR__ . '/ApiClient.php';
require_once __DIR__ . '/AuthService.php';
require_once __DIR__ . '/ProductService.php';

class CartService {
    private ApiClient $apiClient;
    private AuthService $authService;
    private ProductService $productService;
    
    public function __construct() {
        $this->apiClient = new ApiClient();
        $this->authService = new AuthService();
        $this->productService = new ProductService();
    }
    
    /**
     * Add product to cart
     * @param string $productCode Product code to add
     * @param int $quantity Quantity to add
     * @return array Result with success status
     */
    public function addToCart(string $productCode, int $quantity = 1): array {
        try {
            // Validate inputs
            if (empty(trim($productCode))) {
                return [
                    'success' => false,
                    'notification' => [
                        'type' => 'error',
                        'message' => 'Product code is required'
                    ]
                ];
            }
            
            $quantity = max(1, intval($quantity));
            
            // First, verify product exists and is available
            $productResult = $this->productService->getProductByCode($productCode);
            if (!$productResult['success']) {
                return [
                    'success' => false,
                    'notification' => [
                        'type' => 'error',
                        'message' => 'Product not found or unavailable'
                    ]
                ];
            }
            
            $product = $productResult['data'];
            
            // Check stock availability
            if ($product['quantity_available'] < $quantity) {
                return [
                    'success' => false,
                    'notification' => [
                        'type' => 'warning',
                        'message' => 'Insufficient stock available'
                    ]
                ];
            }
            
            // Initialize cart if not set
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }
            
            // Add or update product in cart
            if (isset($_SESSION['cart'][$productCode])) {
                $newQuantity = $_SESSION['cart'][$productCode] + $quantity;
                
                // Check total quantity doesn't exceed stock
                if ($newQuantity > $product['quantity_available']) {
                    return [
                        'success' => false,
                        'notification' => [
                            'type' => 'warning',
                            'message' => 'Cannot add more items than available in stock'
                        ]
                    ];
                }
                
                $_SESSION['cart'][$productCode] = $newQuantity;
            } else {
                $_SESSION['cart'][$productCode] = $quantity;
            }
            
            return [
                'success' => true,
                'data' => [
                    'product_code' => $productCode,
                    'quantity_added' => $quantity,
                    'cart_total_items' => array_sum($_SESSION['cart'])
                ],
                'notification' => [
                    'type' => 'success',
                    'message' => "Added {$quantity} x {$product['description']} to cart"
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error adding to cart: ' . $e->getMessage()
                ]
            ];
        }
    }

    /**
     * Get cart contents with product details
     * @return array Cart items with product information
     */
    public function getCartContents(): array {
        try {
            if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
                return [
                    'success' => true,
                    'data' => [
                        'items' => [],
                        'total_items' => 0,
                        'total_value' => 0.0
                    ],
                    'notification' => [
                        'type' => 'info',
                        'message' => 'Cart is empty'
                    ]
                ];
            }
            
            $cartItems = [];
            $totalValue = 0.0;
            $totalItems = 0;
            
            foreach ($_SESSION['cart'] as $productCode => $quantity) {
                $productResult = $this->productService->getProductByCode($productCode);
                
                if ($productResult['success']) {
                    $product = $productResult['data'];
                    $itemTotal = $product['current_price'] * $quantity;
                    
                    $cartItems[] = [
                        'product_code' => $productCode,
                        'product' => $product,
                        'quantity' => $quantity,
                        'item_total' => $itemTotal
                    ];
                    
                    $totalValue += $itemTotal;
                    $totalItems += $quantity;
                }
            }
            
            return [
                'success' => true,
                'data' => [
                    'items' => $cartItems,
                    'total_items' => $totalItems,
                    'total_value' => round($totalValue, 2)
                ],
                'notification' => [
                    'type' => 'info',
                    'message' => "Cart contains {$totalItems} items"
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'data' => ['items' => [], 'total_items' => 0, 'total_value' => 0.0],
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error loading cart: ' . $e->getMessage()
                ]
            ];
        }
    }

    /**
     * Remove product from cart
     * @param string $productCode Product code to remove
     * @return array Result with success status
     */
    public function removeFromCart(string $productCode): array {
        try {
            if (!isset($_SESSION['cart'][$productCode])) {
                return [
                    'success' => false,
                    'notification' => [
                        'type' => 'warning',
                        'message' => 'Product not found in cart'
                    ]
                ];
            }
            
            unset($_SESSION['cart'][$productCode]);
            
            return [
                'success' => true,
                'notification' => [
                    'type' => 'success',
                    'message' => 'Product removed from cart'
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error removing from cart: ' . $e->getMessage()
                ]
            ];
        }
    }

    /**
     * Clear entire cart
     * @return array Result with success status
     */
    public function clearCart(): array {
        try {
            $_SESSION['cart'] = [];
            
            return [
                'success' => true,
                'notification' => [
                    'type' => 'success',
                    'message' => 'Cart cleared successfully'
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error clearing cart: ' . $e->getMessage()
                ]
            ];
        }
    }

    /**
     * Save current session cart to backend for future use
     * @param string $cartName Optional name for the saved cart
     * @return array Result with success status
     */
    public function saveCartToBackend(string $cartName = ''): array {
        try {
            if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
                return [
                    'success' => false,
                    'notification' => [
                        'type' => 'warning',
                        'message' => 'Cart is empty, nothing to save'
                    ]
                ];
            }
            
            $headers = $this->authService->getAuthHeaders();
            
            // Prepare cart data for backend
            $cartData = [
                'cart_name' => $cartName ?: 'Saved Cart ' . date('Y-m-d H:i:s'),
                'items' => []
            ];
            
            foreach ($_SESSION['cart'] as $productCode => $quantity) {
                $cartData['items'][] = [
                    'product_code' => $productCode,
                    'quantity' => $quantity
                ];
            }
            
            $response = $this->apiClient->post('/api/user/cart/save', $cartData, $headers);
            
            if ($response['success']) {
                $_SESSION['cart_saved'] = true;
                $_SESSION['saved_cart_id'] = $response['data']['cart_id'] ?? null;
                
                return [
                    'success' => true,
                    'data' => $response['data'],
                    'notification' => [
                        'type' => 'success',
                        'message' => 'Cart saved successfully for future use'
                    ]
                ];
            }
            
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => $response['message'] ?? 'Failed to save cart'
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error saving cart: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Load a saved cart from backend to session
     * @param int $cartId ID of the saved cart to load
     * @param bool $merge Whether to merge with current cart or replace
     * @return array Result with success status
     */
    public function loadSavedCart(int $cartId, bool $merge = false): array {
        try {
            $headers = $this->authService->getAuthHeaders();
            $response = $this->apiClient->get("/api/user/cart/{$cartId}", [], $headers);
            
            if (!$response['success']) {
                return [
                    'success' => false,
                    'notification' => [
                        'type' => 'error',
                        'message' => $response['message'] ?? 'Failed to load saved cart'
                    ]
                ];
            }
            
            $savedCart = $response['data'];
            
            if (!$merge) {
                $_SESSION['cart'] = [];
            }
            
            // Load items into session cart
            foreach ($savedCart['items'] as $item) {
                $productCode = $item['product_code'];
                $quantity = $item['quantity'];
                
                // Verify product still exists and has stock
                $productResult = $this->productService->getProductByCode($productCode);
                if ($productResult['success']) {
                    $product = $productResult['data'];
                    
                    // Adjust quantity if stock is insufficient
                    $availableQuantity = min($quantity, $product['quantity_available']);
                    
                    if ($merge && isset($_SESSION['cart'][$productCode])) {
                        $_SESSION['cart'][$productCode] += $availableQuantity;
                    } else {
                        $_SESSION['cart'][$productCode] = $availableQuantity;
                    }
                }
            }
            
            $_SESSION['cart_updated'] = time();
            $_SESSION['cart_saved'] = true;
            $_SESSION['saved_cart_id'] = $cartId;
            
            $totalItems = array_sum($_SESSION['cart']);
            
            return [
                'success' => true,
                'data' => [
                    'cart_name' => $savedCart['cart_name'],
                    'items_loaded' => count($savedCart['items']),
                    'total_items' => $totalItems
                ],
                'notification' => [
                    'type' => 'success',
                    'message' => "Loaded saved cart: {$savedCart['cart_name']} ({$totalItems} items)"
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error loading saved cart: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Get list of user's saved carts
     * @return array List of saved carts
     */
    public function getSavedCarts(): array {
        try {
            $headers = $this->authService->getAuthHeaders();
            $response = $this->apiClient->get('/api/user/carts', [], $headers);
            
            if ($response['success']) {
                $carts = $response['data'] ?? [];
                
                return [
                    'success' => true,
                    'data' => $carts,
                    'notification' => [
                        'type' => 'info',
                        'message' => 'Saved carts loaded successfully'
                    ]
                ];
            }
            
            return [
                'success' => false,
                'data' => [],
                'notification' => [
                    'type' => 'warning',
                    'message' => $response['message'] ?? 'Unable to load saved carts'
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'data' => [],
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error loading saved carts: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Delete a saved cart from backend
     * @param int $cartId ID of the cart to delete
     * @return array Result with success status
     */
    public function deleteSavedCart(int $cartId): array {
        try {
            $headers = $this->authService->getAuthHeaders();
            $response = $this->apiClient->delete("/api/user/cart/{$cartId}", [], $headers);
            
            if ($response['success']) {
                return [
                    'success' => true,
                    'notification' => [
                        'type' => 'success',
                        'message' => 'Saved cart deleted successfully'
                    ]
                ];
            }
            
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => $response['message'] ?? 'Failed to delete saved cart'
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error deleting saved cart: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Get cart summary for display
     * @return array Cart summary information
     */
    public function getCartSummary(): array {
        try {
            $totalItems = 0;
            $totalValue = 0.0;
            
            if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
                foreach ($_SESSION['cart'] as $productCode => $quantity) {
                    $productResult = $this->productService->getProductByCode($productCode);
                    if ($productResult['success']) {
                        $product = $productResult['data'];
                        $totalItems += $quantity;
                        $totalValue += $product['current_price'] * $quantity;
                    }
                }
            }
            
            return [
                'success' => true,
                'data' => [
                    'total_items' => $totalItems,
                    'total_value' => round($totalValue, 2),
                    'is_saved' => $_SESSION['cart_saved'] ?? false,
                    'has_items' => $totalItems > 0
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'data' => [
                    'total_items' => 0,
                    'total_value' => 0.0,
                    'is_saved' => false,
                    'has_items' => false
                ]
            ];
        }
    }
    
    /**
     * Update product quantity in cart
     * @param string $productCode Product code to update
     * @param int $quantity New quantity
     * @return array Result with success status
     */
    public function updateCartItemQuantity(string $productCode, int $quantity): array {
        try {
            if (!isset($_SESSION['cart'][$productCode])) {
                return [
                    'success' => false,
                    'notification' => [
                        'type' => 'warning',
                        'message' => 'Product not found in cart'
                    ]
                ];
            }
            
            if ($quantity <= 0) {
                // Remove item if quantity is zero or negative
                unset($_SESSION['cart'][$productCode]);
                
                return [
                    'success' => true,
                    'notification' => [
                        'type' => 'success',
                        'message' => 'Product removed from cart'
                    ]
                ];
            }
            
            // Verify product exists and has sufficient stock
            $productResult = $this->productService->getProductByCode($productCode);
            if (!$productResult['success']) {
                return [
                    'success' => false,
                    'notification' => [
                        'type' => 'error',
                        'message' => 'Product not found or unavailable'
                    ]
                ];
            }
            
            $product = $productResult['data'];
            
            // Check stock availability
            if ($product['quantity_available'] < $quantity) {
                return [
                    'success' => false,
                    'notification' => [
                        'type' => 'warning',
                        'message' => 'Requested quantity exceeds available stock'
                    ]
                ];
            }
            
            // Update quantity
            $_SESSION['cart'][$productCode] = $quantity;
            
            return [
                'success' => true,
                'data' => [
                    'product_code' => $productCode,
                    'quantity' => $quantity,
                    'cart_total_items' => array_sum($_SESSION['cart'])
                ],
                'notification' => [
                    'type' => 'success',
                    'message' => "Updated quantity for {$product['description']}"
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error updating cart: ' . $e->getMessage()
                ]
            ];
        }
    }
}