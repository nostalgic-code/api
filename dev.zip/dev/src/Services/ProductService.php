# Create ProductService.php file
php_content = '''<?php
// filepath: dev/src/Services/ProductService.php

require_once __DIR__ . '/ApiClient.php';
require_once __DIR__ . '/AuthService.php';

class ProductService {
    private ApiClient $apiClient;
    private AuthService $authService;
    
    public function __construct() {
        $this->apiClient = new ApiClient();
        $this->authService = new AuthService();
    }
    
    /**
     * Get products with optional filters and pagination
     * @param array $filters Optional filter criteria
     * @param array $pagination Optional pagination parameters
     * @return array Products with metadata
     */
    public function getProducts(array $filters = [], array $pagination = []): array {
        try {
            $headers = $this->authService->getAuthHeaders();
            
            // Build query parameters
            $params = array_merge($filters, $pagination);
            
            $response = $this->apiClient->get('/api/products', $params, $headers);
            
            if ($response['success']) {
                $data = $response['data'] ?? [];
                $count = count($data['products'] ?? []);
                
                return [
                    'success' => true,
                    'data' => $data,
                    'notification' => [
                        'type' => 'info',
                        'message' => "Found {$count} products"
                    ]
                ];
            }
            
            return [
                'success' => false,
                'data' => ['products' => [], 'pagination' => [], 'filters_applied' => []],
                'notification' => [
                    'type' => 'warning',
                    'message' => $response['message'] ?? 'Unable to load products'
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'data' => ['products' => [], 'pagination' => [], 'filters_applied' => []],
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error loading products: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    // /**
    //  * Get a specific product by product code
    //  * @param string $productCode The product code to search for
    //  * @return array Product data or error
    //  */
    // public function getProductByCode(string $productCode): array {
    //     try {
    //         if (empty(trim($productCode))) {
    //             return [
    //                 'success' => false,
    //                 'data' => null,
    //                 'notification' => [
    //                     'type' => 'error',
    //                     'message' => 'Product code is required'
    //                 ]
    //             ];
    //         }
            
    //         $headers = $this->authService->getAuthHeaders();
    //         $response = $this->apiClient->get("/api/products/{$productCode}", [], $headers);
            
    //         if ($response['success']) {
    //             return [
    //                 'success' => true,
    //                 'data' => $response['data'],
    //                 'notification' => [
    //                     'type' => 'success',
    //                     'message' => 'Product found successfully'
    //                 ]
    //             ];
    //         }
            
    //         return [
    //             'success' => false,
    //             'data' => null,
    //             'notification' => [
    //                 'type' => 'warning',
    //                 'message' => $response['message'] ?? 'Product not found'
    //             ]
    //         ];
            
    //     } catch (Exception $e) {
    //         return [
    //             'success' => false,
    //             'data' => null,
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error retrieving product: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }
    
    /**
     * Search products by query string
     * @param string $query Search query string
     * @param array $filters Additional filter criteria
     * @return array Search results
     */
    public function searchProducts(string $query, array $filters = []): array {
        try {
            if (empty(trim($query))) {
                return [
                    'success' => false,
                    'data' => ['products' => [], 'count' => 0],
                    'notification' => [
                        'type' => 'error',
                        'message' => 'Search query is required'
                    ]
                ];
            }
            
            $headers = $this->authService->getAuthHeaders();
            $params = array_merge(['query' => trim($query)], $filters);
            
            $response = $this->apiClient->get('/api/products/search', $params, $headers);
            
            if ($response['success']) {
                $data = $response['data'] ?? [];
                $count = $data['count'] ?? 0;
                
                return [
                    'success' => true,
                    'data' => $data,
                    'notification' => [
                        'type' => 'info',
                        'message' => "Found {$count} products matching '{$query}'"
                    ]
                ];
            }
            
            return [
                'success' => false,
                'data' => ['products' => [], 'count' => 0],
                'notification' => [
                    'type' => 'warning',
                    'message' => $response['message'] ?? 'No products found'
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'data' => ['products' => [], 'count' => 0],
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error searching products: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Search products by multiple product codes
     * @param array $productCodes Array of product codes
     * @param string $partialCode Partial code for search
     * @param bool $exact Whether to perform exact match
     * @return array Search results
     */
    public function searchProductsByCodes(array $productCodes = [], string $partialCode = '', bool $exact = false): array {
        try {
            $params = [];
            
            if (!empty($productCodes)) {
                $params['codes'] = implode(',', $productCodes);
            }
            
            if (!empty(trim($partialCode))) {
                $params['partial'] = trim($partialCode);
                $params['exact'] = $exact ? 'true' : 'false';
            }
            
            if (empty($params)) {
                return [
                    'success' => false,
                    'data' => ['products' => [], 'count' => 0],
                    'notification' => [
                        'type' => 'error',
                        'message' => 'Either product codes or partial code is required'
                    ]
                ];
            }
            
            $headers = $this->authService->getAuthHeaders();
            $response = $this->apiClient->get('/api/products/search-by-codes', $params, $headers);
            
            if ($response['success']) {
                $data = $response['data'] ?? [];
                $count = $data['count'] ?? 0;
                
                return [
                    'success' => true,
                    'data' => $data,
                    'notification' => [
                        'type' => 'info',
                        'message' => "Found {$count} products"
                    ]
                ];
            }
            
            return [
                'success' => false,
                'data' => ['products' => [], 'count' => 0],
                'notification' => [
                    'type' => 'warning',
                    'message' => $response['message'] ?? 'No products found'
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'data' => ['products' => [], 'count' => 0],
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error searching products by codes: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    // /**
    //  * Get products by category
    //  * @param string $category Product category
    //  * @return array Products in the category
    //  */
    // public function getProductsByCategory(string $category): array {
    //     try {
    //         if (empty(trim($category))) {
    //             return [
    //                 'success' => false,
    //                 'data' => [],
    //                 'notification' => [
    //                     'type' => 'error',
    //                     'message' => 'Category is required'
    //                 ]
    //             ];
    //         }
            
    //         $headers = $this->authService->getAuthHeaders();
    //         $response = $this->apiClient->get('/api/products/category/' . urlencode($category), [], $headers);
            
    //         if ($response['success']) {
    //             $products = $response['data'] ?? [];
    //             $count = count($products);
                
    //             return [
    //                 'success' => true,
    //                 'data' => $products,
    //                 'notification' => [
    //                     'type' => 'info',
    //                     'message' => "Found {$count} products in '{$category}' category"
    //                 ]
    //             ];
    //         }
            
    //         return [
    //             'success' => false,
    //             'data' => [],
    //             'notification' => [
    //                 'type' => 'warning',
    //                 'message' => $response['message'] ?? "No products found in '{$category}' category"
    //             ]
    //         ];
            
    //     } catch (\Exception $e) {
    //         return [
    //             'success' => false,
    //             'data' => [],
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error getting products by category: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }
    
    // /**
    //  * Get products by brand
    //  * @param string $brand Product brand
    //  * @return array Products from the brand
    //  */
    // public function getProductsByBrand(string $brand): array {
    //     try {
    //         if (empty(trim($brand))) {
    //             return [
    //                 'success' => false,
    //                 'data' => [],
    //                 'notification' => [
    //                     'type' => 'error',
    //                     'message' => 'Brand is required'
    //                 ]
    //             ];
    //         }
            
    //         $headers = $this->authService->getAuthHeaders();
    //         $response = $this->apiClient->get('/api/products/brand/' . urlencode($brand), [], $headers);
            
    //         if ($response['success']) {
    //             $products = $response['data'] ?? [];
    //             $count = count($products);
                
    //             return [
    //                 'success' => true,
    //                 'data' => $products,
    //                 'notification' => [
    //                     'type' => 'info',
    //                     'message' => "Found {$count} products from '{$brand}' brand"
    //                 ]
    //             ];
    //         }
            
    //         return [
    //             'success' => false,
    //             'data' => [],
    //             'notification' => [
    //                 'type' => 'warning',
    //                 'message' => $response['message'] ?? "No products found from '{$brand}' brand"
    //             ]
    //         ];
            
    //     } catch (\\Exception $e) {
    //         return [
    //             'success' => false,
    //             'data' => [],
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error getting products by brand: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }
    
    // /**
    //  * Get product statistics and metrics
    //  * @return array Product statistics
    //  */
    // public function getProductStatistics(): array {
    //     try {
    //         $headers = $this->authService->getAuthHeaders();
    //         $response = $this->apiClient->get('/api/products/statistics', [], $headers);
            
    //         if ($response['success']) {
    //             $data = $response['data'] ?? [];
                
    //             // Format statistics for consistent structure
    //             $stats = [
    //                 'total_products' => $data['total_products'] ?? 0,
    //                 'available_products' => $data['available_products'] ?? 0,
    //                 'unavailable_products' => $data['unavailable_products'] ?? 0,
    //                 'categories' => $data['categories'] ?? [],
    //                 'top_brands' => $data['top_brands'] ?? [],
    //                 'price_statistics' => $data['price_statistics'] ?? []
    //             ];
                
    //             return [
    //                 'success' => true,
    //                 'data' => $stats,
    //                 'notification' => [
    //                     'type' => 'success',
    //                     'message' => 'Product statistics loaded successfully'
    //                 ]
    //             ];
    //         }
            
    //         return [
    //             'success' => false,
    //             'data' => $this->getDefaultStatistics(),
    //             'notification' => [
    //                 'type' => 'warning',
    //                 'message' => $response['message'] ?? 'Unable to load product statistics'
    //             ]
    //         ];
            
    //     } catch (\\Exception $e) {
    //         return [
    //             'success' => false,
    //             'data' => $this->getDefaultStatistics(),
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error loading product statistics: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }
    
    // /**
    //  * Get all available product categories
    //  * @return array List of categories
    //  */
    // public function getCategories(): array {
    //     try {
    //         $headers = $this->authService->getAuthHeaders();
    //         $response = $this->apiClient->get('/api/products/categories', [], $headers);
            
    //         if ($response['success']) {
    //             $categories = $response['data'] ?? [];
                
    //             return [
    //                 'success' => true,
    //                 'data' => $categories,
    //                 'notification' => [
    //                     'type' => 'info',
    //                     'message' => 'Categories loaded successfully'
    //                 ]
    //             ];
    //         }
            
    //         return [
    //             'success' => false,
    //             'data' => [],
    //             'notification' => [
    //                 'type' => 'warning',
    //                 'message' => $response['message'] ?? 'Unable to load categories'
    //             ]
    //         ];
            
    //     } catch (\\Exception $e) {
    //         return [
    //             'success' => false,
    //             'data' => [],
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error loading categories: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }
    
    // /**
    //  * Get all available product brands
    //  * @return array List of brands
    //  */
    // public function getBrands(): array {
    //     try {
    //         $headers = $this->authService->getAuthHeaders();
    //         $response = $this->apiClient->get('/api/products/brands', [], $headers);
            
    //         if ($response['success']) {
    //             $brands = $response['data'] ?? [];
                
    //             return [
    //                 'success' => true,
    //                 'data' => $brands,
    //                 'notification' => [
    //                     'type' => 'info',
    //                     'message' => 'Brands loaded successfully'
    //                 ]
    //             ];
    //         }
            
    //         return [
    //             'success' => false,
    //             'data' => [],
    //             'notification' => [
    //                 'type' => 'warning',
    //                 'message' => $response['message'] ?? 'Unable to load brands'
    //             ]
    //         ];
            
    //     } catch (\\Exception $e) {
    //         return [
    //             'success' => false,
    //             'data' => [],
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error loading brands: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }
    
    /**
     * Validate product data
     * @param array $productData Product data to validate
     * @return array Validation result with errors if any
     */
    public function validateProductData(array $productData): array {
        $errors = [];
        
        try {
            // Required fields validation
            $requiredFields = ['product_code', 'description', 'category', 'brand', 'current_price'];
            
            foreach ($requiredFields as $field) {
                if (!isset($productData[$field]) || empty(trim($productData[$field]))) {
                    $errors[] = "Field '{$field}' is required";
                }
            }
            
            // Product code validation
            if (isset($productData['product_code'])) {
                $productCode = trim($productData['product_code']);
                if (strlen($productCode) < 3) {
                    $errors[] = 'Product code must be at least 3 characters long';
                }
                if (!preg_match('/^[A-Za-z0-9\\-_]+$/', $productCode)) {
                    $errors[] = 'Product code can only contain letters, numbers, hyphens, and underscores';
                }
            }
            
            // Price validation
            if (isset($productData['current_price'])) {
                $price = $productData['current_price'];
                if (!is_numeric($price) || $price < 0) {
                    $errors[] = 'Price must be a positive number';
                }
                if ($price > 999999.99) {
                    $errors[] = 'Price cannot exceed 999,999.99';
                }
            }
            
            // Quantity validation
            if (isset($productData['quantity_available'])) {
                $quantity = $productData['quantity_available'];
                if (!is_numeric($quantity) || $quantity < 0 || $quantity != (int)$quantity) {
                    $errors[] = 'Quantity must be a non-negative integer';
                }
                if ($quantity > 999999) {
                    $errors[] = 'Quantity cannot exceed 999,999';
                }
            }
            
            // Description validation
            if (isset($productData['description'])) {
                $description = trim($productData['description']);
                if (strlen($description) < 10) {
                    $errors[] = 'Description must be at least 10 characters long';
                }
                if (strlen($description) > 1000) {
                    $errors[] = 'Description cannot exceed 1000 characters';
                }
            }
            
            // Category and brand validation
            foreach (['category', 'brand'] as $field) {
                if (isset($productData[$field])) {
                    $value = trim($productData[$field]);
                    if (strlen($value) > 100) {
                        $errors[] = ucfirst($field) . ' cannot exceed 100 characters';
                    }
                }
            }
            
            // Unit of measure validation
            if (isset($productData['unit_of_measure'])) {
                $uom = trim($productData['unit_of_measure']);
                if (strlen($uom) > 20) {
                    $errors[] = 'Unit of measure cannot exceed 20 characters';
                }
            }
            
            $isValid = empty($errors);
            
            return [
                'success' => $isValid,
                'valid' => $isValid,
                'errors' => $errors,
                'notification' => [
                    'type' => $isValid ? 'success' : 'error',
                    'message' => $isValid ? 'Product data is valid' : 'Product data validation failed'
                ]
            ];
            
        } catch (\\Exception $e) {
            return [
                'success' => false,
                'valid' => false,
                'errors' => ['Validation error: ' . $e->getMessage()],
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error validating product data: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Get default statistics structure
     * @return array Default statistics
     */
    private function getDefaultStatistics(): array {
        return [
            'total_products' => 0,
            'available_products' => 0,
            'unavailable_products' => 0,
            'categories' => [],
            'top_brands' => [],
            'price_statistics' => [
                'min_price' => 0,
                'max_price' => 0,
                'avg_price' => 0,
                'price_ranges' => [
                    'under_100' => 0,
                    'between_100_500' => 0,
                    'over_500' => 0
                ]
            ]
        ];
    }


    // /**
    //  * Add product to cart
    //  * @param string $productCode Product code to add
    //  * @param int $quantity Quantity to add
    //  * @return array Result with success status
    //  */
    // public function addToCart(string $productCode, int $quantity = 1): array {
    //     try {
    //         // Validate inputs
    //         if (empty(trim($productCode))) {
    //             return [
    //                 'success' => false,
    //                 'notification' => [
    //                     'type' => 'error',
    //                     'message' => 'Product code is required'
    //                 ]
    //             ];
    //         }
            
    //         $quantity = max(1, intval($quantity));
            
    //         // First, verify product exists and is available
    //         $productResult = $this->getProductByCode($productCode);
    //         if (!$productResult['success']) {
    //             return [
    //                 'success' => false,
    //                 'notification' => [
    //                     'type' => 'error',
    //                     'message' => 'Product not found or unavailable'
    //                 ]
    //             ];
    //         }
            
    //         $product = $productResult['data'];
            
    //         // Check stock availability
    //         if ($product['is_available'] < $quantity) {
    //             return [
    //                 'success' => false,
    //                 'notification' => [
    //                     'type' => 'warning',
    //                     'message' => 'Insufficient stock available'
    //                 ]
    //             ];
    //         }
            
    //         // Initialize cart if not set
    //         if (!isset($_SESSION['cart'])) {
    //             $_SESSION['cart'] = [];
    //         }
            
    //         // Add or update product in cart
    //         if (isset($_SESSION['cart'][$productCode])) {
    //             $newQuantity = $_SESSION['cart'][$productCode] + $quantity;
                
    //             // Check total quantity doesn't exceed stock
    //             if ($newQuantity > $product['quantity_available']) {
    //                 return [
    //                     'success' => false,
    //                     'notification' => [
    //                         'type' => 'warning',
    //                         'message' => 'Cannot add more items than available in stock'
    //                     ]
    //                 ];
    //             }
                
    //             $_SESSION['cart'][$productCode] = $newQuantity;
    //         } else {
    //             $_SESSION['cart'][$productCode] = $quantity;
    //         }
            
    //         return [
    //             'success' => true,
    //             'data' => [
    //                 'product_code' => $productCode,
    //                 'quantity_added' => $quantity,
    //                 'cart_total_items' => array_sum($_SESSION['cart'])
    //             ],
    //             'notification' => [
    //                 'type' => 'success',
    //                 'message' => "Added {$quantity} x {$product['description']} to cart"
    //             ]
    //         ];
            
    //     } catch (\Exception $e) {
    //         return [
    //             'success' => false,
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error adding to cart: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }

    // /**
    //  * Get cart contents with product details
    //  * @return array Cart items with product information
    //  */
    // public function getCartContents(): array {
    //     try {
    //         if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    //             return [
    //                 'success' => true,
    //                 'data' => [
    //                     'items' => [],
    //                     'total_items' => 0,
    //                     'total_value' => 0.0
    //                 ],
    //                 'notification' => [
    //                     'type' => 'info',
    //                     'message' => 'Cart is empty'
    //                 ]
    //             ];
    //         }
            
    //         $cartItems = [];
    //         $totalValue = 0.0;
    //         $totalItems = 0;
            
    //         foreach ($_SESSION['cart'] as $productCode => $quantity) {
    //             $productResult = $this->getProductByCode($productCode);
                
    //             if ($productResult['success']) {
    //                 $product = $productResult['data'];
    //                 $itemTotal = $product['price'] * $quantity;
                    
    //                 $cartItems[] = [
    //                     'product_code' => $productCode,
    //                     'product' => $product,
    //                     'quantity' => $quantity,
    //                     'item_total' => $itemTotal
    //                 ];
                    
    //                 $totalValue += $itemTotal;
    //                 $totalItems += $quantity;
    //             }
    //         }
            
    //         return [
    //             'success' => true,
    //             'data' => [
    //                 'items' => $cartItems,
    //                 'total_items' => $totalItems,
    //                 'total_value' => round($totalValue, 2)
    //             ],
    //             'notification' => [
    //                 'type' => 'info',
    //                 'message' => "Cart contains {$totalItems} items"
    //             ]
    //         ];
            
    //     } catch (\Exception $e) {
    //         return [
    //             'success' => false,
    //             'data' => ['items' => [], 'total_items' => 0, 'total_value' => 0.0],
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error loading cart: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }

    // /**
    //  * Remove product from cart
    //  * @param string $productCode Product code to remove
    //  * @return array Result with success status
    //  */
    // public function removeFromCart(string $productCode): array {
    //     try {
    //         if (!isset($_SESSION['cart'][$productCode])) {
    //             return [
    //                 'success' => false,
    //                 'notification' => [
    //                     'type' => 'warning',
    //                     'message' => 'Product not found in cart'
    //                 ]
    //             ];
    //         }
            
    //         unset($_SESSION['cart'][$productCode]);
            
    //         return [
    //             'success' => true,
    //             'notification' => [
    //                 'type' => 'success',
    //                 'message' => 'Product removed from cart'
    //             ]
    //         ];
            
    //     } catch (\Exception $e) {
    //         return [
    //             'success' => false,
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error removing from cart: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }

    // /**
    //  * Clear entire cart
    //  * @return array Result with success status
    //  */
    // public function clearCart(): array {
    //     try {
    //         $_SESSION['cart'] = [];
            
    //         return [
    //             'success' => true,
    //             'notification' => [
    //                 'type' => 'success',
    //                 'message' => 'Cart cleared successfully'
    //             ]
    //         ];
            
    //     } catch (\Exception $e) {
    //         return [
    //             'success' => false,
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error clearing cart: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }

    // /**
    //  * Save current session cart to backend for future use
    //  * @param string $cartName Optional name for the saved cart
    //  * @return array Result with success status
    //  */
    // public function saveCartToBackend(string $cartName = ''): array {
    //     try {
    //         if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    //             return [
    //                 'success' => false,
    //                 'notification' => [
    //                     'type' => 'warning',
    //                     'message' => 'Cart is empty, nothing to save'
    //                 ]
    //             ];
    //         }
            
    //         $headers = $this->authService->getAuthHeaders();
            
    //         // Prepare cart data for backend
    //         $cartData = [
    //             'cart_name' => $cartName ?: 'Saved Cart ' . date('Y-m-d H:i:s'),
    //             'items' => []
    //         ];
            
    //         foreach ($_SESSION['cart'] as $productCode => $quantity) {
    //             $cartData['items'][] = [
    //                 'product_code' => $productCode,
    //                 'quantity' => $quantity
    //             ];
    //         }
            
    //         $response = $this->apiClient->post('/api/user/cart/save', $cartData, $headers);
            
    //         if ($response['success']) {
    //             $_SESSION['cart_saved'] = true;
    //             $_SESSION['saved_cart_id'] = $response['data']['cart_id'] ?? null;
                
    //             return [
    //                 'success' => true,
    //                 'data' => $response['data'],
    //                 'notification' => [
    //                     'type' => 'success',
    //                     'message' => 'Cart saved successfully for future use'
    //                 ]
    //             ];
    //         }
            
    //         return [
    //             'success' => false,
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => $response['message'] ?? 'Failed to save cart'
    //             ]
    //         ];
            
    //     } catch (\\Exception $e) {
    //         return [
    //             'success' => false,
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error saving cart: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }
    
    // /**
    //  * Load a saved cart from backend to session
    //  * @param int $cartId ID of the saved cart to load
    //  * @param bool $merge Whether to merge with current cart or replace
    //  * @return array Result with success status
    //  */
    // public function loadSavedCart(int $cartId, bool $merge = false): array {
    //     try {
    //         $headers = $this->authService->getAuthHeaders();
    //         $response = $this->apiClient->get("/api/user/cart/{$cartId}", [], $headers);
            
    //         if (!$response['success']) {
    //             return [
    //                 'success' => false,
    //                 'notification' => [
    //                     'type' => 'error',
    //                     'message' => $response['message'] ?? 'Failed to load saved cart'
    //                 ]
    //             ];
    //         }
            
    //         $savedCart = $response['data'];
            
    //         if (!$merge) {
    //             $_SESSION['cart'] = [];
    //         }
            
    //         // Load items into session cart
    //         foreach ($savedCart['items'] as $item) {
    //             $productCode = $item['product_code'];
    //             $quantity = $item['quantity'];
                
    //             // Verify product still exists and has stock
    //             $productResult = $this->getProductByCode($productCode);
    //             if ($productResult['success']) {
    //                 $product = $productResult['data'];
                    
    //                 // Adjust quantity if stock is insufficient
    //                 $availableQuantity = min($quantity, $product['is_available']);
                    
    //                 if ($merge && isset($_SESSION['cart'][$productCode])) {
    //                     $_SESSION['cart'][$productCode] += $availableQuantity;
    //                 } else {
    //                     $_SESSION['cart'][$productCode] = $availableQuantity;
    //                 }
    //             }
    //         }
            
    //         $_SESSION['cart_updated'] = time();
    //         $_SESSION['cart_saved'] = true;
    //         $_SESSION['saved_cart_id'] = $cartId;
            
    //         $totalItems = array_sum($_SESSION['cart']);
            
    //         return [
    //             'success' => true,
    //             'data' => [
    //                 'cart_name' => $savedCart['cart_name'],
    //                 'items_loaded' => count($savedCart['items']),
    //                 'total_items' => $totalItems
    //             ],
    //             'notification' => [
    //                 'type' => 'success',
    //                 'message' => "Loaded saved cart: {$savedCart['cart_name']} ({$totalItems} items)"
    //             ]
    //         ];
            
    //     } catch (\\Exception $e) {
    //         return [
    //             'success' => false,
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error loading saved cart: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }
    
    // /**
    //  * Get list of user's saved carts
    //  * @return array List of saved carts
    //  */
    // public function getSavedCarts(): array {
    //     try {
    //         $headers = $this->authService->getAuthHeaders();
    //         $response = $this->apiClient->get('/api/user/carts', [], $headers);
            
    //         if ($response['success']) {
    //             $carts = $response['data'] ?? [];
                
    //             return [
    //                 'success' => true,
    //                 'data' => $carts,
    //                 'notification' => [
    //                     'type' => 'info',
    //                     'message' => 'Saved carts loaded successfully'
    //                 ]
    //             ];
    //         }
            
    //         return [
    //             'success' => false,
    //             'data' => [],
    //             'notification' => [
    //                 'type' => 'warning',
    //                 'message' => $response['message'] ?? 'Unable to load saved carts'
    //             ]
    //         ];
            
    //     } catch (\\Exception $e) {
    //         return [
    //             'success' => false,
    //             'data' => [],
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error loading saved carts: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }
    
    // /**
    //  * Delete a saved cart from backend
    //  * @param int $cartId ID of the cart to delete
    //  * @return array Result with success status
    //  */
    // public function deleteSavedCart(int $cartId): array {
    //     try {
    //         $headers = $this->authService->getAuthHeaders();
    //         $response = $this->apiClient->delete("/api/user/cart/{$cartId}", [], $headers);
            
    //         if ($response['success']) {
    //             return [
    //                 'success' => true,
    //                 'notification' => [
    //                     'type' => 'success',
    //                     'message' => 'Saved cart deleted successfully'
    //                 ]
    //             ];
    //         }
            
    //         return [
    //             'success' => false,
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => $response['message'] ?? 'Failed to delete saved cart'
    //             ]
    //         ];
            
    //     } catch (\\Exception $e) {
    //         return [
    //             'success' => false,
    //             'notification' => [
    //                 'type' => 'error',
    //                 'message' => 'Error deleting saved cart: ' . $e->getMessage()
    //             ]
    //         ];
    //     }
    // }
    
    // /**
    //  * Get cart summary for display
    //  * @return array Cart summary information
    //  */
    // public function getCartSummary(): array {
    //     try {
    //         $totalItems = 0;
    //         $totalValue = 0.0;
            
    //         if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    //             foreach ($_SESSION['cart'] as $productCode => $quantity) {
    //                 $productResult = $this->getProductByCode($productCode);
    //                 if ($productResult['success']) {
    //                     $product = $productResult['data'];
    //                     $totalItems += $quantity;
    //                     $totalValue += $product['price'] * $quantity;
    //                 }
    //             }
    //         }
            
    //         return [
    //             'success' => true,
    //             'data' => [
    //                 'total_items' => $totalItems,
    //                 'total_value' => round($totalValue, 2),
    //                 'is_saved' => $_SESSION['cart_saved'] ?? false,
    //                 'has_items' => $totalItems > 0
    //             ]
    //         ];
            
    //     } catch (\\Exception $e) {
    //         return [
    //             'success' => false,
    //             'data' => [
    //                 'total_items' => 0,
    //                 'total_value' => 0.0,
    //                 'is_saved' => false,
    //                 'has_items' => false
    //             ]
    //         ];
    //     }
    // }
}