<?php
// filepath: dev/src/Services/SessionManager.php

class SessionManager {
    
    public function set(string $key, $value): void {
        $_SESSION[$key] = $value;
    }
    
    public function get(string $key, $default = null) {
        return $_SESSION[$key] ?? $default;
    }
    
    public function has(string $key): bool {
        return isset($_SESSION[$key]);
    }
    
    public function remove(string $key): void {
        unset($_SESSION[$key]);
    }
    
    public function destroy(): void {
        session_destroy();
        $_SESSION = [];
    }
    
    public function regenerate(): void {
        session_regenerate_id(true);
    }
    
    public function isAuthenticated(): bool {
        return $this->get('authenticated', false) === true && 
               $this->has('session_token') && 
               $this->has('user');
    }
    
    public function getUser(): ?array {
        return $this->get('user');
    }
    
    public function getSessionToken(): ?string {
        return $this->get('session_token');
    }
    
    public function getUserType(): ?string {
        return $this->get('user_type');
    }
    
    public function isPlatformUser(): bool {
        return $this->isAuthenticated() && $this->getUserType() === 'platform_user';
    }
    
    public function isCustomerUser(): bool {
        return $this->isAuthenticated() && $this->getUserType() === 'customer_user';
    }
    
    public function getUserRole(): ?string {
        $user = $this->getUser();
        return $user['role'] ?? null;
    }
}