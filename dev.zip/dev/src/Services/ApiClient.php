<?php
// filepath: dev/src/Services/ApiClient.php

class ApiClient {
    private string $baseUrl;
    private int $timeout = 10; // Reduced from 30 to 10 seconds for debugging
    
    public function __construct() {
        $this->baseUrl = API_BASE_URL;
    }
    
    protected function request(string $method, string $endpoint, array $data = [], array $headers = []): array {
        // Ensure endpoint starts with /
        if (!str_starts_with($endpoint, '/')) {
            $endpoint = '/' . $endpoint;
        }
        
        $url = $this->baseUrl . $endpoint;
        
        // Log the request for debugging
        if (DEV_MODE) {
            error_log("API Request: $method $url");
            if (!empty($data)) {
                error_log("Request Data: " . json_encode($data));
            }
        }
        
        $ch = curl_init();
        $defaultHeaders = [
            'Content-Type: application/json',
            'Accept: application/json',
            'Origin: https://zezwebox.co.za' // Add origin header for CORS
        ];
        
        $headers = array_merge($defaultHeaders, $headers);
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 5, // Add connection timeout
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_ENCODING => '', // Enable gzip
        ]);
        
        if (in_array($method, ['POST', 'PUT', 'PATCH']) && !empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        $curlInfo = curl_getinfo($ch);
        curl_close($ch);
        
        // Log response for debugging
        if (DEV_MODE) {
            error_log("API Response Code: $httpCode");
            if ($response) {
                error_log("API Response: " . substr($response, 0, 1000));
            }
            if ($error) {
                error_log("CURL Error: $error");
            }
        }
        
        if ($error) {
            return [
                'status_code' => 0,
                'data' => null,
                'error' => $error,
                'success' => false,
                'message' => 'Network error: ' . $error
            ];
        }
        
        // Handle empty response
        if (empty($response)) {
            return [
                'status_code' => $httpCode,
                'data' => null,
                'error' => 'Empty response from server',
                'success' => false,
                'message' => 'No response from server'
            ];
        }
        
        $decodedResponse = json_decode($response, true);
        
        // Handle JSON decode errors
        if (json_last_error() !== JSON_ERROR_NONE) {
            return [
                'status_code' => $httpCode,
                'data' => null,
                'error' => 'JSON decode error: ' . json_last_error_msg(),
                'raw_response' => $response,
                'success' => false,
                'message' => 'Invalid response format'
            ];
        }
        
        return [
            'status_code' => $httpCode,
            'data' => $decodedResponse,
            'success' => $httpCode >= 200 && $httpCode < 300,
            'message' => $decodedResponse['message'] ?? null
        ];
    }
    
    public function get(string $endpoint, array $params = [], array $headers = []): array {
        if (!empty($params)) {
            $endpoint .= '?' . http_build_query($params);
        }
        return $this->request('GET', $endpoint, [], $headers);
    }
    
    public function post(string $endpoint, array $data = [], array $headers = []): array {
        return $this->request('POST', $endpoint, $data, $headers);
    }
    
    public function put(string $endpoint, array $data = [], array $headers = []): array {
        return $this->request('PUT', $endpoint, $data, $headers);
    }
    
    public function patch(string $endpoint, array $data = [], array $headers = []): array {
        return $this->request('PATCH', $endpoint, $data, $headers);
    }
    
    public function delete(string $endpoint, array $headers = []): array {
        return $this->request('DELETE', $endpoint, [], $headers);
    }
}