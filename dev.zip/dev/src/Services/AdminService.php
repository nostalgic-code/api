<?php
// filepath: dev/src/Services/AdminService.php

require_once __DIR__ . '/ApiClient.php';
require_once __DIR__ . '/AuthService.php';

class AdminService {
    private ApiClient $apiClient;
    private AuthService $authService;
    
    public function __construct() {
        $this->apiClient = new ApiClient();
        $this->authService = new AuthService();
    }
    
    /**
     * Get dashboard statistics from system stats endpoint
     * @return array System-wide statistics
     */
    public function getDashboardStats(): array {
        try {
            $headers = $this->authService->getAuthHeaders();
            $response = $this->apiClient->get('/api/admin/system/stats', [], $headers);
            
            if ($response['success']) {
                $data = $response['data'] ?? [];
                
                // Calculate total users (customer_users + platform_users)
                $customerUsers = $data['users']['customer_users']['total'] ?? 0;
                $platformUsers = $data['users']['platform_users']['total'] ?? 0;
                $totalUsers = $customerUsers + $platformUsers;
                
                // Get pending approvals from customer_users
                $pendingApprovals = $data['users']['customer_users']['pending'] ?? 0;
                
                // Get active users (approved customer_users + all platform_users)
                $activeUsers = ($data['users']['customer_users']['approved'] ?? 0) + $platformUsers;
                
                // Get rejected users from customer_users
                $rejectedUsers = $data['users']['customer_users']['rejected'] ?? 0;
                
                // Build customer breakdown by status
                $customerBreakdown = [
                    'approved' => $data['customers']['approved'] ?? 0,
                    'pending' => $data['customers']['pending'] ?? 0,
                    'suspended' => $data['customers']['suspended'] ?? 0,
                    'total' => $data['customers']['total'] ?? 0
                ];
                
                // Build user breakdown by role
                $userBreakdown = [
                    'customer_users' => $customerUsers,
                    'platform_users' => $platformUsers,
                    'admins' => $data['users']['platform_users']['admins'] ?? 0,
                    'approved' => $data['users']['customer_users']['approved'] ?? 0,
                    'pending' => $data['users']['customer_users']['pending'] ?? 0,
                    'rejected' => $data['users']['customer_users']['rejected'] ?? 0
                ];
                
                // Format the response to match expected dashboard structure
                return [
                    'success' => true,
                    'data' => [
                        'total_customers' => $data['customers']['total'] ?? 0,
                        'total_users' => $totalUsers,
                        'pending_approvals' => $pendingApprovals,
                        'total_depots' => $data['depots']['total'] ?? 0,
                        'active_users' => $activeUsers,
                        'rejected_users' => $rejectedUsers,
                        'customer_breakdown' => $customerBreakdown,
                        'user_breakdown' => $userBreakdown,
                        // Additional data that might be useful
                        'permission_codes' => $data['permission_codes']['total'] ?? 0
                    ],
                    'notification' => [
                        'type' => 'success',
                        'message' => 'Dashboard statistics loaded successfully'
                    ]
                ];
            }
            
            // API call failed
            return [
                'success' => false,
                'data' => $this->getDefaultStats(),
                'notification' => [
                    'type' => 'error',
                    'message' => $response['message'] ?? 'Failed to load dashboard statistics'
                ]
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'data' => $this->getDefaultStats(),
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error loading dashboard: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Approve a pending user
     * @param int $userId
     * @param array $data
     * @return array
     */
    public function approveUser(int $userId, array $data = []): array {
        try {
            $headers = $this->authService->getAuthHeaders();
            $response = $this->apiClient->post("/api/admin/users/{$userId}/approve", $data, $headers);
            
            if ($response['success']) {
                return [
                    'success' => true,
                    'data' => $response['data'],
                    'notification' => [
                        'type' => 'success',
                        'message' => 'User approved successfully'
                    ]
                ];
            }
            
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => $response['message'] ?? 'Failed to approve user'
                ]
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error approving user: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Reject a pending user
     * @param int $userId
     * @param string $reason
     * @return array
     */
    public function rejectUser(int $userId, string $reason): array {
        try {
            $headers = $this->authService->getAuthHeaders();
            $response = $this->apiClient->post("/api/admin/users/{$userId}/reject", 
                ['reason' => $reason], 
                $headers
            );
            
            if ($response['success']) {
                return [
                    'success' => true,
                    'data' => $response['data'],
                    'notification' => [
                        'type' => 'success',
                        'message' => 'User rejected successfully'
                    ]
                ];
            }
            
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => $response['message'] ?? 'Failed to reject user'
                ]
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error rejecting user: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Get pending users with notification handling
     * @param array $filters
     * @return array
     */
    public function getPendingUsers(array $filters = []): array {
        try {
            $headers = $this->authService->getAuthHeaders();
            $response = $this->apiClient->get('/api/admin/pending-users', $filters, $headers);
            
            if ($response['success']) {
                $count = count($response['data']['users'] ?? []);
                return [
                    'success' => true,
                    'data' => $response['data'],
                    'notification' => [
                        'type' => 'info',
                        'message' => "Found {$count} pending users"
                    ]
                ];
            }
            
            return [
                'success' => false,
                'data' => ['users' => [], 'count' => 0],
                'notification' => [
                    'type' => 'warning',
                    'message' => 'Unable to load pending users'
                ]
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'data' => ['users' => [], 'count' => 0],
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error loading pending users: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Get active users with notification handling
     * @param array $filters
     * @return array
     */
    public function getActiveUsers(array $filters = []): array {
        try {
            $headers = $this->authService->getAuthHeaders();
            $response = $this->apiClient->get('/api/admin/active-users', $filters, $headers);
            
            if ($response['success']) {
                $count = count($response['data']['users'] ?? []);
                return [
                    'success' => true,
                    'users' => $response['data']['users'] ?? [],
                    'count' => $response['data']['count'] ?? $count
                ];
            }
            
            return [
                'success' => false,
                'users' => [],
                'count' => 0,
                'notification' => [
                    'type' => 'warning',
                    'message' => 'Unable to load active users'
                ]
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'users' => [],
                'count' => 0,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error loading active users: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Update customer status
     * @param int $customerId
     * @param string $status
     * @param string|null $reason
     * @return array
     */
    public function updateCustomerStatus(int $customerId, string $status, ?string $reason = null): array {
        try {
            $headers = $this->authService->getAuthHeaders();
            $data = ['status' => $status];
            if ($reason) {
                $data['reason'] = $reason;
            }
            
            $response = $this->apiClient->put("/api/admin/customers/{$customerId}/status", $data, $headers);
            
            if ($response['success']) {
                return [
                    'success' => true,
                    'data' => $response['data'],
                    'notification' => [
                        'type' => 'success',
                        'message' => "Customer status updated to {$status}"
                    ]
                ];
            }
            
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => $response['message'] ?? 'Failed to update customer status'
                ]
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'notification' => [
                    'type' => 'error',
                    'message' => 'Error updating customer status: ' . $e->getMessage()
                ]
            ];
        }
    }
    
    /**
     * Get default stats structure
     * @return array
     */
    private function getDefaultStats(): array {
        return [
            'total_customers' => 0,
            'total_users' => 0,
            'pending_approvals' => 0,
            'total_depots' => 0,
            'active_users' => 0,
            'rejected_users' => 0,
            'customer_breakdown' => [],
            'user_breakdown' => []
        ];
    }
}