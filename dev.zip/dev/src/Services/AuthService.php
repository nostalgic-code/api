<?php
// filepath: dev/src/Services/AuthService.php

require_once __DIR__ . '/ApiClient.php';
require_once __DIR__ . '/SessionManager.php';

class AuthService {
    private ApiClient $apiClient;
    private SessionManager $sessionManager;
    
    public function __construct() {
        $this->apiClient = new ApiClient();
        $this->sessionManager = new SessionManager();
    }
    
    public function sendOtp(string $phone): array {
        // Use the correct endpoint with leading slash
        $response = $this->apiClient->post('/api/auth/send-otp', ['phone' => $phone]);
        
        if ($response['success'] && isset($response['data']['success']) && $response['data']['success']) {
            // Store phone temporarily in session for verification
            $this->sessionManager->set('pending_phone', $phone);
            $this->sessionManager->set('otp_expires_at', time() + ($response['data']['expires_in'] ?? 180));
            
            return [
                'success' => true,
                'message' => $response['data']['message'] ?? 'OTP sent successfully',
                'expires_in' => $response['data']['expires_in'] ?? 180
            ];
        }
        
        // Better error handling
        $errorMessage = $response['data']['message'] ?? 
                       $response['message'] ?? 
                       $response['error'] ?? 
                       'Failed to send OTP';
        
        return [
            'success' => false,
            'message' => $errorMessage,
            'debug' => DEV_MODE ? $response : null
        ];
    }
    
    public function verifyOtp(string $phone, string $otp): array {
        $response = $this->apiClient->post('/api/auth/verify-otp', [
            'phone' => $phone,
            'otp' => $otp
        ]);
        
        if ($response['success'] && isset($response['data']['success']) && $response['data']['success']) {
            // Store session data
            $this->sessionManager->set('authenticated', true);
            $this->sessionManager->set('session_token', $response['data']['session_token']);
            $this->sessionManager->set('user_type', $response['data']['user_type']);
            $this->sessionManager->set('user', $response['data']['user']);
            $this->sessionManager->regenerate(); // Regenerate session ID for security
            
            // Clear temporary data
            $this->sessionManager->remove('pending_phone');
            $this->sessionManager->remove('otp_expires_at');
            
            return [
                'success' => true,
                'message' => 'Login successful',
                'user' => $response['data']['user'],
                'user_type' => $response['data']['user_type'],
                'redirect_url' => $this->getRedirectUrl($response['data']['user_type'])
            ];
        }
        
        // Better error handling
        $errorMessage = $response['data']['message'] ?? 
                       $response['message'] ?? 
                       $response['error'] ?? 
                       'Invalid OTP';
        
        return [
            'success' => false,
            'message' => $errorMessage,
            'debug' => DEV_MODE ? $response : null
        ];
    }
    
    public function register(array $data): array {
        // Validate required fields
        $requiredFields = ['customer_code', 'name', 'email', 'role'];
        foreach ($requiredFields as $field) {
            if (empty($data[$field])) {
                return [
                    'success' => false,
                    'message' => ucfirst(str_replace('_', ' ', $field)) . ' is required'
                ];
            }
        }
        
        // Validate role
        $validRoles = ['owner', 'staff', 'viewer'];
        if (!in_array($data['role'], $validRoles)) {
            return [
                'success' => false,
                'message' => 'Invalid role. Must be one of: owner, staff, viewer'
            ];
        }
        
        // Send registration request
        $response = $this->apiClient->post('/api/auth/register', [
            'customer_code' => $data['customer_code'],
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['phone'] ?? null,
            'role' => $data['role']
        ]);
        
        if ($response['success'] && isset($response['data']['success']) && $response['data']['success']) {
            return [
                'success' => true,
                'message' => $response['data']['message'] ?? 'Registration successful',
                'user' => $response['data']['user'] ?? null,
                'requires_approval' => $response['data']['requires_approval'] ?? false
            ];
        }
        
        // Better error handling
        $errorMessage = $response['data']['message'] ?? 
                       $response['message'] ?? 
                       $response['error'] ?? 
                       'Registration failed';
        
        return [
            'success' => false,
            'message' => $errorMessage,
            'debug' => DEV_MODE ? $response : null
        ];
    }

    public function validateSession(): bool {
        $token = $this->sessionManager->getSessionToken();
        
        if (!$token) {
            return false;
        }
        
        $response = $this->apiClient->post('/api/auth/validate-session', ['session_token' => $token]);
        
        if ($response['success'] && isset($response['data']['valid']) && $response['data']['valid']) {
            // Update user data if provided
            if (isset($response['data']['user'])) {
                $this->sessionManager->set('user', $response['data']['user']);
            }
            return true;
        }
        
        // Invalid session, clear it
        $this->logout();
        return false;
    }
    
    public function logout(): bool {
        $token = $this->sessionManager->getSessionToken();
        
        if ($token) {
            $this->apiClient->post('/api/auth/logout', ['session_token' => $token]);
        }
        
        $this->sessionManager->destroy();
        return true;
    }
    
    public function requireAuth(): void {
        if (!$this->sessionManager->isAuthenticated() || !$this->validateSession()) {
            header('Location: /dev/login.php');
            exit;
        }
    }
    
    public function requirePlatformUser(): void {
        $this->requireAuth();
        
        if ($this->sessionManager->get('user_type') !== 'platform_user') {
            header('Location: /dev/home.php');
            exit;
        }
    }
    
    public function requireCustomerUser(): void {
        $this->requireAuth();
        
        if ($this->sessionManager->get('user_type') !== 'customer_user') {
            header('Location: /dev/admin/');
            exit;
        }
    }
    
    private function getRedirectUrl(string $userType): string {
        return match($userType) {
            'platform_user' => '/dev/admin/',
            'customer_user' => '/dev/home.php',
            default => '/dev/home.php'
        };
    }
    
    public function getAuthHeaders(): array {
        $token = $this->sessionManager->getSessionToken();
        return $token ? ['Authorization: Bearer ' . $token] : [];
    }
}