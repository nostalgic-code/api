document.addEventListener('DOMContentLoaded', function() {
    // Phone form handling
    const phoneForm = document.getElementById('phoneForm');
    const otpForm = document.getElementById('otpForm');
    const messageDiv = document.getElementById('messageDiv');
    const messageText = document.getElementById('messageText');
    const timerDiv = document.getElementById('timer');
    const changePhoneBtn = document.getElementById('changePhoneBtn');
    
    // Registration form handling
    const registerForm = document.getElementById('registerForm');
    const successDiv = document.getElementById('successDiv');
    const successText = document.getElementById('successText');
    
    let otpTimer;
    let currentPhone = '';
    
    function showMessage(message, isError = true) {
        messageText.textContent = message;
        messageText.className = isError ? 'text-red-600 font-medium' : 'text-green-600 font-medium';
        messageDiv.classList.remove('hidden');
        
        setTimeout(() => {
            messageDiv.classList.add('hidden');
        }, 5000);
    }
    
    function showSuccessMessage(message) {
        if (successText && successDiv) {
            successText.textContent = message;
            successDiv.classList.remove('hidden');
            
            setTimeout(() => {
                successDiv.classList.add('hidden');
            }, 5000);
        }
    }
    
    function startOtpTimer(seconds) {
        let timeLeft = seconds;
        
        otpTimer = setInterval(() => {
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            
            timerDiv.textContent = `OTP expires in ${minutes}:${seconds.toString().padStart(2, '0')}`;
            
            if (timeLeft <= 0) {
                clearInterval(otpTimer);
                timerDiv.textContent = 'OTP expired';
                timerDiv.classList.add('text-red-600');
            }
            
            timeLeft--;
        }, 1000);
    }
    
    function formatPhoneNumber(phone) {
        // Remove all non-numeric characters
        phone = phone.replace(/\D/g, '');
        
        // Handle South African numbers
        if (phone.startsWith('27')) {
            return '+' + phone;
        } else if (phone.startsWith('0')) {
            return '+27' + phone.substring(1);
        } else if (phone.length === 9) {
            return '+27' + phone;
        }
        
        return phone;
    }
    
    function validateEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }
    
    // Phone form submission
    if (phoneForm) {
        phoneForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const phoneInput = document.getElementById('phone');
            const phone = formatPhoneNumber(phoneInput.value);
            
            if (!phone || phone.length < 10) {
                showMessage('Please enter a valid phone number');
                return;
            }
            
            currentPhone = phone;
            const sendOtpBtn = document.getElementById('sendOtpBtn');
            sendOtpBtn.disabled = true;
            sendOtpBtn.textContent = 'Sending...';
            
            try {
                const response = await fetch('/dev/login.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        action: 'send_otp',
                        phone: phone
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    phoneForm.classList.add('hidden');
                    otpForm.classList.remove('hidden');
                    
                    showMessage(data.message || 'OTP sent successfully', false);
                    startOtpTimer(data.expires_in || 180);
                    
                    // Focus on OTP input
                    document.getElementById('otp').focus();
                } else {
                    showMessage(data.message || 'Failed to send OTP');
                }
            } catch (error) {
                showMessage('An error occurred. Please try again.');
                console.error('Error:', error);
            } finally {
                sendOtpBtn.disabled = false;
                sendOtpBtn.textContent = 'Send OTP';
            }
        });
    }
    
    // OTP form submission
    if (otpForm) {
        otpForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const otpInput = document.getElementById('otp');
            const otp = otpInput.value.trim();
            
            if (otp.length !== 6) {
                showMessage('Please enter a 6-digit OTP');
                return;
            }
            
            const verifyBtn = document.getElementById('verifyOtpBtn');
            verifyBtn.disabled = true;
            verifyBtn.textContent = 'Verifying...';
            
            try {
                const response = await fetch('/dev/login.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        action: 'verify_otp',
                        phone: currentPhone,
                        otp: otp
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    showMessage('Login successful! Redirecting...', false);
                    clearInterval(otpTimer);
                    
                    setTimeout(() => {
                        window.location.href = data.redirect_url || '/dev/home.php';
                    }, 1000);
                } else {
                    showMessage(data.message || 'Invalid OTP');
                    otpInput.value = '';
                    otpInput.focus();
                }
            } catch (error) {
                showMessage('An error occurred. Please try again.');
                console.error('Error:', error);
            } finally {
                verifyBtn.disabled = false;
                verifyBtn.textContent = 'Verify OTP';
            }
        });
    }
    
    // Change phone button
    if (changePhoneBtn) {
        changePhoneBtn.addEventListener('click', () => {
            clearInterval(otpTimer);
            otpForm.classList.add('hidden');
            phoneForm.classList.remove('hidden');
            document.getElementById('otp').value = '';
            timerDiv.textContent = '';
            timerDiv.classList.remove('text-red-600');
        });
    }
    
    // Registration form submission
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(registerForm);
            const data = {
                customer_code: formData.get('customer_code').trim(),
                name: formData.get('name').trim(),
                email: formData.get('email').trim(),
                phone: formData.get('phone').trim(),
                role: formData.get('role')
            };
            
            // Validate required fields
            if (!data.customer_code || !data.name || !data.email || !data.role) {
                showMessage('Please fill in all required fields');
                return;
            }
            
            // Validate email
            if (!validateEmail(data.email)) {
                showMessage('Please enter a valid email address');
                return;
            }
            
            // Format phone if provided
            if (data.phone) {
                data.phone = formatPhoneNumber(data.phone);
            }
            
            const registerBtn = document.getElementById('registerBtn');
            registerBtn.disabled = true;
            registerBtn.textContent = 'Creating Account...';
            
            try {
                const response = await fetch('/dev/register.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showSuccessMessage(result.message || 'Registration successful!');
                    
                    if (result.requires_approval) {
                        showMessage('Your account requires approval. You will be notified once approved.', false);
                    }
                    
                    // Clear form
                    registerForm.reset();
                    
                    // Redirect to login after 2 seconds
                    setTimeout(() => {
                        window.location.href = '/dev/login.php';
                    }, 2000);
                } else {
                    showMessage(result.message || 'Registration failed');
                }
            } catch (error) {
                showMessage('An error occurred. Please try again.');
                console.error('Error:', error);
            } finally {
                registerBtn.disabled = false;
                registerBtn.textContent = 'Create Account';
            }
        });
    }
});