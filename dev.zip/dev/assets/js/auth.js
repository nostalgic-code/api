const phoneForm = document.getElementById('phoneForm');
const otpForm = document.getElementById('otpForm');
const phoneInput = document.getElementById('phone');
const otpInput = document.getElementById('otp');
const messageDiv = document.getElementById('messageDiv');
const messageText = document.getElementById('messageText');
const timerDiv = document.getElementById('timer');
const changePhoneBtn = document.getElementById('changePhoneBtn');

let phoneNumber = '';
let countdownInterval;

// Show message
function showMessage(message, isError = false) {
    messageDiv.classList.remove('hidden', 'bg-green-50', 'bg-red-50');
    messageText.classList.remove('text-green-800', 'text-red-800');
    
    if (isError) {
        messageDiv.classList.add('bg-red-50');
        messageText.classList.add('text-red-800');
    } else {
        messageDiv.classList.add('bg-green-50');
        messageText.classList.add('text-green-800');
    }
    
    messageText.textContent = message;
}

// Start OTP timer
function startOtpTimer(seconds) {
    let timeLeft = seconds;
    
    timerDiv.textContent = `Time remaining: ${formatTime(timeLeft)}`;
    
    countdownInterval = setInterval(() => {
        timeLeft--;
        
        if (timeLeft <= 0) {
            clearInterval(countdownInterval);
            timerDiv.textContent = 'OTP expired. Please request a new one.';
            document.getElementById('verifyOtpBtn').disabled = true;
            return;
        }
        
        timerDiv.textContent = `Time remaining: ${formatTime(timeLeft)}`;
    }, 1000);
}

// Format time
function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

// Send OTP
phoneForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    phoneNumber = phoneInput.value.trim();
    const sendOtpBtn = document.getElementById('sendOtpBtn');
    
    sendOtpBtn.disabled = true;
    sendOtpBtn.textContent = 'Sending...';
    
    try {
        const formData = new FormData();
        formData.append('action', 'send_otp');
        formData.append('phone', phoneNumber);
        
        console.log('Sending OTP request for phone:', phoneNumber);
        
        const response = await fetch('/dev/login.php', {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        });
        
        console.log('Response status:', response.status);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const text = await response.text();
        console.log('Response text:', text);
        
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error('Failed to parse JSON:', e);
            throw new Error('Invalid response format');
        }
        
        if (data.success) {
            phoneForm.classList.add('hidden');
            otpForm.classList.remove('hidden');
            showMessage(data.message);
            startOtpTimer(data.expires_in || 180);
            otpInput.focus();
        } else {
            showMessage(data.message, true);
            if (data.debug) {
                console.error('Debug info:', data.debug);
            }
        }
    } catch (error) {
        console.error('Error:', error);
        showMessage('An error occurred. Please try again.', true);
    } finally {
        sendOtpBtn.disabled = false;
        sendOtpBtn.textContent = 'Send OTP';
    }
});

// Verify OTP
otpForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const otp = otpInput.value.trim();
    const verifyOtpBtn = document.getElementById('verifyOtpBtn');
    
    verifyOtpBtn.disabled = true;
    verifyOtpBtn.textContent = 'Verifying...';
    
    try {
        const formData = new FormData();
        formData.append('action', 'verify_otp');
        formData.append('phone', phoneNumber);
        formData.append('otp', otp);
        
        const response = await fetch('/dev/login.php', {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            showMessage('Login successful! Redirecting...');
            
            // Use redirect URL from response or default based on user type
            const redirectUrl = data.redirect_url || (data.user_type === 'platform_user' ? '/dev/admin/' : '/dev/home.php');
            
            setTimeout(() => {
                window.location.href = redirectUrl;
            }, 1500);
        } else {
            showMessage(data.message, true);
            otpInput.select();
        }
    } catch (error) {
        showMessage('An error occurred. Please try again.', true);
    } finally {
        verifyOtpBtn.disabled = false;
        verifyOtpBtn.textContent = 'Verify OTP';
    }
});

// Change phone number
changePhoneBtn.addEventListener('click', () => {
    clearInterval(countdownInterval);
    otpForm.classList.add('hidden');
    phoneForm.classList.remove('hidden');
    otpInput.value = '';
    phoneInput.focus();
});

// Auto-focus OTP input
otpInput.addEventListener('input', (e) => {
    if (e.target.value.length === 6) {
        otpForm.dispatchEvent(new Event('submit'));
    }
});