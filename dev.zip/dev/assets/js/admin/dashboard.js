// Dashboard-specific JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check if there's an initial notification from PHP
    if (window.dashboardData && window.dashboardData.notification) {
        showToast(window.dashboardData.notification.message, window.dashboardData.notification.type);
    }
    
    // Initialize dashboard
    initializeDashboard();
    
    // Set up auto-refresh only if API endpoints are available
    // Comment out for now until API endpoints are implemented
    // setInterval(refreshDashboardStats, 60000); // Refresh every minute
});

// Toggle card expansion
function toggleCardExpansion(cardId) {
    const card = document.querySelector(`[data-stat-id="${cardId}"]`);
    if (!card) return;
    
    const expansion = card.querySelector('.card-expansion');
    const isExpanded = card.classList.contains('expanded');
    
    // Close all other expanded cards
    document.querySelectorAll('.expandable-card.expanded').forEach(otherCard => {
        if (otherCard !== card) {
            otherCard.classList.remove('expanded');
            otherCard.querySelector('.card-expansion').classList.add('hidden');
        }
    });
    
    // Toggle current card
    if (isExpanded) {
        card.classList.remove('expanded');
        expansion.classList.add('hidden');
    } else {
        card.classList.add('expanded');
        expansion.classList.remove('hidden');
    }
}

// Close expanded cards when clicking outside
document.addEventListener('click', function(event) {
    if (!event.target.closest('.expandable-card')) {
        document.querySelectorAll('.expandable-card.expanded').forEach(card => {
            card.classList.remove('expanded');
            card.querySelector('.card-expansion').classList.add('hidden');
        });
    }
});

function initializeDashboard() {
    // Initialize charts
    initializeUserRoleChart();
    initializeCustomerStatusChart();
    
    // Update notification badges
    updateNotificationBadges();
    
    // Load recent activity
    loadRecentActivity();
}

function initializeUserRoleChart() {
    const ctx = document.getElementById('userRoleChart');
    if (!ctx) return;
    
    const userBreakdown = window.dashboardData.stats.user_breakdown || {};
    
    // Skip if no data
    if (Object.keys(userBreakdown).length === 0) {
        ctx.parentElement.innerHTML = '<p class="text-center text-gray-500">No user data available</p>';
        return;
    }
    
    new Chart(ctx.getContext('2d'), {
        type: 'doughnut',
        data: {
            labels: Object.keys(userBreakdown).map(role => 
                role.charAt(0).toUpperCase() + role.slice(1)
            ),
            datasets: [{
                data: Object.values(userBreakdown),
                backgroundColor: [
                    '#3B82F6', // Blue
                    '#10B981', // Green
                    '#F59E0B', // Yellow
                    '#EF4444'  // Red
                ],
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        usePointStyle: true,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((context.parsed / total) * 100).toFixed(1);
                            return context.label + ': ' + context.parsed + ' (' + percentage + '%)';
                        }
                    }
                }
            }
        }
    });
}

function initializeCustomerStatusChart() {
    const ctx = document.getElementById('customerStatusChart');
    if (!ctx) return;
    
    const customerBreakdown = window.dashboardData.stats.customer_breakdown || {};
    
    // Skip if no data
    if (Object.keys(customerBreakdown).length === 0) {
        ctx.parentElement.innerHTML = '<p class="text-center text-gray-500">No customer data available</p>';
        return;
    }
    
    new Chart(ctx.getContext('2d'), {
        type: 'bar',
        data: {
            labels: Object.keys(customerBreakdown).map(status => 
                status.charAt(0).toUpperCase() + status.slice(1)
            ),
            datasets: [{
                label: 'Customers',
                data: Object.values(customerBreakdown),
                backgroundColor: '#3B82F6',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

function updateNotificationBadges() {
    const notifications = window.dashboardData.notifications || {};
    
    // Since we don't have a notification endpoint, use the stats data
    const stats = window.dashboardData.stats || {};
    
    // Update using the global functions from admin.js
    // For now, we'll use pending_approvals as the notification count
    updateNotificationBadge(stats.pending_approvals || 0);
    updatePendingBadge(stats.pending_approvals || 0);
}

async function loadRecentActivity() {
    const activityFeed = document.getElementById('activityFeed');
    if (!activityFeed) return;
    
    // For now, we'll keep the mock data
    // In production, this would fetch from an API endpoint
    // try {
    //     const response = await apiRequest('/activity/recent');
    //     renderActivityFeed(response.activities);
    // } catch (error) {
    //     console.error('Failed to load recent activity:', error);
    // }
}

function updateStatCards(stats) {
    // Update main stat cards
    const statMappings = {
        'total-customers': stats.total_customers || 0,
        'total-users': stats.total_users || 0,
        'pending-approvals': stats.pending_approvals || 0,
        'total-depots': stats.total_depots || 0,
        'active-users': stats.active_users || 0,
        'rejected-users': stats.rejected_users || 0,
        'permission-codes': stats.permission_codes || 0
    };
    
    Object.entries(statMappings).forEach(([statId, value]) => {
        const card = document.querySelector(`[data-stat-id="${statId}"] .stat-value`);
        if (card) {
            card.textContent = new Intl.NumberFormat().format(value);
        }
        
        // Update badge for pending approvals
        if (statId === 'pending-approvals') {
            const badge = document.querySelector(`[data-stat-id="${statId}"] .stat-badge`);
            if (badge) {
                badge.style.display = value > 0 ? 'block' : 'none';
            }
        }
    });
    
    // Update active users count in total users card
    const activeUsersSpan = document.querySelector(`[data-stat-id="total-users"] .stat-active`);
    if (activeUsersSpan) {
        activeUsersSpan.textContent = new Intl.NumberFormat().format(stats.active_users || 0);
    }
    
    // Update customer breakdown in expanded view
    if (stats.customer_breakdown) {
        Object.entries(stats.customer_breakdown).forEach(([status, value]) => {
            const element = document.querySelector(`.customer-stat[data-status="${status}"]`);
            if (element) {
                element.textContent = new Intl.NumberFormat().format(value);
            }
        });
        
        // Update approved count in main card
        const approvedCustomers = document.querySelector('[data-stat-id="total-customers"] .text-green-600');
        if (approvedCustomers && stats.customer_breakdown.approved !== undefined) {
            approvedCustomers.innerHTML = `<i class="fas fa-arrow-up"></i> ${new Intl.NumberFormat().format(stats.customer_breakdown.approved)} approved`;
        }
    }
    
    // Update user breakdown in expanded view
    if (stats.user_breakdown) {
        // Update by type
        ['customer_users', 'platform_users', 'admins'].forEach(type => {
            const element = document.querySelector(`.user-stat[data-type="${type}"]`);
            if (element && stats.user_breakdown[type] !== undefined) {
                element.textContent = new Intl.NumberFormat().format(stats.user_breakdown[type]);
            }
        });
        
        // Update by status
        ['approved', 'pending', 'rejected'].forEach(status => {
            const element = document.querySelector(`.user-stat[data-status="${status}"]`);
            if (element && stats.user_breakdown[status] !== undefined) {
                element.textContent = new Intl.NumberFormat().format(stats.user_breakdown[status]);
            }
        });
    }
}

async function refreshDashboardStats() {
    try {
        // Check if API endpoint exists before calling
        const statsEndpoint = '/api/admin/system/stats';
        
        // For development, check if endpoints exist
        const checkEndpoint = async (endpoint) => {
            try {
                const response = await fetch(window.location.origin + '/dev' + endpoint, {
                    method: 'HEAD'
                });
                return response.ok;
            } catch {
                return false;
            }
        };
        
        const statsAvailable = await checkEndpoint(statsEndpoint);
        
        if (!statsAvailable) {
            console.warn('Stats API endpoint not available yet');
            showToast('Stats API endpoint not available', 'warning');
            return;
        }
        
        // Fetch updated stats
        const response = await apiRequest(statsEndpoint);
        
        // Handle notification from response
        if (response.notification) {
            showToast(response.notification.message, response.notification.type);
        }
        
        // Log the response for debugging
        console.group('Dashboard Stats Response');
        console.log('Success:', response.success);
        console.log('Data:', response.data);
        console.log('Total Users:', response.data?.total_users || 0);
        console.log('User Breakdown:', response.data?.user_breakdown || {});
        console.groupEnd();
        
        if (response.success && response.data) {
            // Update the global dashboard data
            window.dashboardData.stats = response.data;
            
            // Update stat cards
            updateStatCards(response.data);
            
            // Re-initialize charts with new data
            initializeUserRoleChart();
            initializeCustomerStatusChart();
            
            // Update notification badges with new stats
            updateNotificationBadges();
        }
        
    } catch (error) {
        console.error('Failed to refresh dashboard:', error);
        showToast('Failed to refresh dashboard: ' + error.message, 'error');
    }
}