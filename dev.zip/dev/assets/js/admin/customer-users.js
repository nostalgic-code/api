// Customer Users Management JavaScript
(function() {
    'use strict';
    
    // Global variables
    let currentUserId = null;
    let pendingUsersData = [];
    let activeUsersData = [];  // Add this line
    
    // Configuration
    const config = {
        activeTab: null, // Will be set from PHP
        currentPage: 'customer_users'
    };
    
    // Initialize module
    function init(options) {
        // Set configuration from PHP
        config.activeTab = options.activeTab || 'pending';
        
        // Initialize page when DOM is ready
        document.addEventListener('DOMContentLoaded', function() {
            if (config.activeTab === 'pending') {
                loadPendingUsers();
            } else if (config.activeTab === 'active') {
                loadActiveUsers();
            }
            
            // Set up search functionality
            setupSearch();
            setupActiveSearch();
            setupRoleFilter();
        });
    }
    
    // Set up search functionality
    function setupSearch() {
        const searchInput = document.getElementById('searchPending');
        if (searchInput) {
            let searchTimeout;
            searchInput.addEventListener('input', function(e) {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    const searchTerm = e.target.value.trim();
                    if (searchTerm.length >= 2 || searchTerm.length === 0) {
                        loadPendingUsers(searchTerm);
                    }
                }, 300);
            });
        }
    }
    
    // Set up active users search functionality
    function setupActiveSearch() {
        const searchInput = document.getElementById('searchActive');
        if (searchInput) {
            let searchTimeout;
            searchInput.addEventListener('input', function(e) {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    loadActiveUsers(e.target.value.trim());
                }, 300);
            });
        }
    }
    
    // Set up role filter
    function setupRoleFilter() {
        const roleFilter = document.getElementById('roleFilter');
        if (roleFilter) {
            roleFilter.addEventListener('change', function(e) {
                loadActiveUsers(document.getElementById('searchActive')?.value || '', e.target.value);
            });
        }
    }

    // Load pending users
    function loadPendingUsers(searchTerm = '') {
        const tableBody = document.getElementById('pendingUsersTableBody');
        const loadingState = document.getElementById('loadingState');
        const emptyState = document.getElementById('emptyState');
        const errorState = document.getElementById('errorState');
        const pendingTable = document.querySelector('#pendingUsersSection .overflow-x-auto');
        const pendingCount = document.getElementById('pendingCount');
        
        // Show loading state
        tableBody.innerHTML = '';
        loadingState.classList.remove('hidden');
        emptyState.classList.add('hidden');
        errorState.classList.add('hidden');
        pendingTable.classList.add('hidden');
        
        // Build URL with search parameter if provided
        let url = '?page=customer_users&action=get_pending_users';
        if (searchTerm) {
            url += '&search=' + encodeURIComponent(searchTerm);
        }
        
        fetch(url, {
            method: 'GET',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(result => {
            loadingState.classList.add('hidden');
            
            if (result.users && result.users.length > 0) {
                pendingUsersData = result.users;
                
                // Update count
                if (pendingCount) {
                    pendingCount.textContent = result.count || result.users.length;
                }
                
                // Show table
                pendingTable.classList.remove('hidden');
                
                // Populate table
                result.users.forEach(user => {
                    const row = createPendingUserRow(user);
                    tableBody.appendChild(row);
                });
            } else {
                // No pending users
                emptyState.classList.remove('hidden');
                if (pendingCount) {
                    pendingCount.textContent = '0';
                }
                pendingUsersData = [];
            }
        })
        .catch(error => {
            loadingState.classList.add('hidden');
            errorState.classList.remove('hidden');
            if (typeof showToast === 'function') {
                showToast('Error loading pending users', 'error');
            }
            console.error('Error:', error);
        });
    }
    
    // Create table row for pending user
    function createPendingUserRow(user) {
        const row = document.createElement('tr');
        row.className = 'hover:bg-gray-50';
        
        // Create initials for avatar
        const initials = user.name.split(' ').map(n => n[0]).join('').toUpperCase();
        
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="flex items-center">
                    <div class="flex-shrink-0 h-10 w-10">
                        <div class="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                            <span class="text-gray-600 font-medium text-sm">${initials}</span>
                        </div>
                    </div>
                    <div class="ml-4">
                        <div class="text-sm font-medium text-gray-900">${escapeHtml(user.name)}</div>
                    </div>
                </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900">${escapeHtml(user.email)}</div>
                <div class="text-sm text-gray-500">${escapeHtml(user.phone || 'No phone')}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900">${escapeHtml(user.customer.name)}</div>
                <div class="text-xs text-gray-500">Code: ${escapeHtml(user.customer.code)}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">
                    ${escapeHtml(user.role.charAt(0).toUpperCase() + user.role.slice(1))}
                </span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                <div>${formatDate(user.created_at)}</div>
                <div class="text-xs text-gray-400">${user.days_pending} day${user.days_pending !== 1 ? 's' : ''} ago</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <div class="flex items-center gap-2">
                    <button onclick="CustomerUsers.openApproveModal(${user.id})" 
                            class="text-green-600 hover:text-green-900 transition-colors duration-200"
                            title="Approve user">
                        <i class="fas fa-check-circle"></i>
                    </button>
                    <button onclick="CustomerUsers.openRejectModal(${user.id})" 
                            class="text-red-600 hover:text-red-900 transition-colors duration-200"
                            title="Reject user">
                        <i class="fas fa-times-circle"></i>
                    </button>
                    <button onclick="CustomerUsers.viewUserDetails(${user.id})" 
                            class="text-blue-600 hover:text-blue-900 transition-colors duration-200"
                            title="View details">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </td>
        `;
        return row;
    }
    
    // Format date
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
    
    // Escape HTML to prevent XSS
    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text ? text.replace(/[&<>"']/g, m => map[m]) : '';
    }
    
    // Open approve modal
    function openApproveModal(userId) {
        currentUserId = userId;
        const user = pendingUsersData.find(u => u.id === userId);
        
        if (user) {
            document.getElementById('approveModalContent').innerHTML = `
                <div class="space-y-3">
                    <div>
                        <label class="text-sm font-medium text-gray-500">Name</label>
                        <p class="text-sm text-gray-900">${escapeHtml(user.name)}</p>
                    </div>
                    <div>
                        <label class="text-sm font-medium text-gray-500">Email</label>
                        <p class="text-sm text-gray-900">${escapeHtml(user.email)}</p>
                    </div>
                    <div>
                        <label class="text-sm font-medium text-gray-500">Phone</label>
                        <p class="text-sm text-gray-900">${escapeHtml(user.phone || 'Not provided')}</p>
                    </div>
                    <div>
                        <label class="text-sm font-medium text-gray-500">Customer</label>
                        <p class="text-sm text-gray-900">${escapeHtml(user.customer.name)} (${escapeHtml(user.customer.code)})</p>
                    </div>
                    <div>
                        <label class="text-sm font-medium text-gray-500">Role</label>
                        <p class="text-sm text-gray-900">${escapeHtml(user.role.charAt(0).toUpperCase() + user.role.slice(1))}</p>
                    </div>
                </div>
            `;
        }
        
        document.getElementById('approveModal').classList.remove('hidden');
    }
    
    // Close approve modal
    function closeApproveModal() {
        document.getElementById('approveModal').classList.add('hidden');
        currentUserId = null;
    }
    
    // Confirm approve
    function confirmApprove() {
        if (!currentUserId) return;
        
        fetch('?page=customer_users&action=approve_user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                user_id: currentUserId
            })
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                if (typeof showToast === 'function') {
                    showToast(result.notification.message, result.notification.type);
                }
                closeApproveModal();
                loadPendingUsers(); // Reload the list
            } else {
                if (typeof showToast === 'function') {
                    showToast(result.notification.message || 'Failed to approve user', 'error');
                }
            }
        })
        .catch(error => {
            if (typeof showToast === 'function') {
                showToast('Error approving user', 'error');
            }
            console.error('Error:', error);
        });
    }
    
    // Open reject modal
    function openRejectModal(userId) {
        currentUserId = userId;
        const user = pendingUsersData.find(u => u.id === userId);
        
        if (user) {
            document.getElementById('rejectModalContent').innerHTML = `
                <div class="space-y-3">
                    <div>
                        <label class="text-sm font-medium text-gray-500">Name</label>
                        <p class="text-sm text-gray-900">${escapeHtml(user.name)}</p>
                    </div>
                    <div>
                        <label class="text-sm font-medium text-gray-500">Email</label>
                        <p class="text-sm text-gray-900">${escapeHtml(user.email)}</p>
                    </div>
                    <div>
                        <label class="text-sm font-medium text-gray-500">Customer</label>
                        <p class="text-sm text-gray-900">${escapeHtml(user.customer.name)} (${escapeHtml(user.customer.code)})</p>
                    </div>
                </div>
            `;
        }
        
        document.getElementById('rejectModal').classList.remove('hidden');
        document.getElementById('rejectionReason').value = '';
    }
    
    // Close reject modal
    function closeRejectModal() {
        document.getElementById('rejectModal').classList.add('hidden');
        currentUserId = null;
    }
    
    // Confirm reject
    function confirmReject() {
        if (!currentUserId) return;
        
        const reason = document.getElementById('rejectionReason').value.trim();
        if (!reason) {
            if (typeof showToast === 'function') {
                showToast('Please provide a rejection reason', 'warning');
            }
            return;
        }
        
        fetch('?page=customer_users&action=reject_user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                user_id: currentUserId,
                reason: reason
            })
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                if (typeof showToast === 'function') {
                    showToast(result.notification.message, result.notification.type);
                }
                closeRejectModal();
                loadPendingUsers(); // Reload the list
            } else {
                if (typeof showToast === 'function') {
                    showToast(result.notification.message || 'Failed to reject user', 'error');
                }
            }
        })
        .catch(error => {
            if (typeof showToast === 'function') {
                showToast('Error rejecting user', 'error');
            }
            console.error('Error:', error);
        });
    }
    
    // Add viewUserDetails function to the public API
    function viewUserDetails(userId) {
        const user = pendingUsersData.find(u => u.id === userId) || activeUsersData.find(u => u.id === userId);
        if (user) {
            // Implement view details functionality
            console.log('View details for user:', user);
            // You can open a modal or navigate to a details page
        }
    }

    // Load active users
    function loadActiveUsers(searchTerm = '', roleFilter = '') {
        const tableBody = document.getElementById('activeUsersTableBody');
        const loadingState = document.getElementById('activeLoadingState');
        const emptyState = document.getElementById('activeEmptyState');
        const errorState = document.getElementById('activeErrorState');
        const activeTable = document.querySelector('#activeUsersSection .shadow-sm'); // Changed from .overflow-x-auto
        
        // Show loading state
        if (tableBody) tableBody.innerHTML = '';
        if (loadingState) loadingState.classList.remove('hidden');
        if (emptyState) emptyState.classList.add('hidden');
        if (errorState) errorState.classList.add('hidden');
        if (activeTable) activeTable.classList.add('hidden');
        
        // Build URL with search and filter parameters
        let url = '?page=customer_users&action=get_active_users';
        if (searchTerm) {
            url += '&search=' + encodeURIComponent(searchTerm);
        }
        if (roleFilter) {
            url += '&role=' + encodeURIComponent(roleFilter);
        }
        
        fetch(url, {
            method: 'GET',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(result => {
            if (loadingState) loadingState.classList.add('hidden');
            
            if (result.users && result.users.length > 0) {
                activeUsersData = result.users;
                
                // Show table
                if (activeTable) activeTable.classList.remove('hidden');
                
                // Populate table
                result.users.forEach(user => {
                    const row = createActiveUserRow(user);
                    if (tableBody) tableBody.appendChild(row);
                });
            } else {
                // No active users
                if (emptyState) emptyState.classList.remove('hidden');
                activeUsersData = [];
            }
        })
        .catch(error => {
            if (loadingState) loadingState.classList.add('hidden');
            if (errorState) errorState.classList.remove('hidden');
            if (typeof showToast === 'function') {
                showToast('Error loading active users', 'error');
            }
            console.error('Error:', error);
        });
    }
    
    // Create table row for active user (updated without last login column)
    function createActiveUserRow(user) {
        const row = document.createElement('tr');
        row.className = 'hover:bg-gray-50';
        
        // Create initials for avatar (limit to 2 characters)
        const initials = user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
        
        // Format depot access
        let depotAccess = 'None';
        if (user.depot_access) {
            if (Array.isArray(user.depot_access)) {
                depotAccess = user.depot_access.join(', ');
            } else if (typeof user.depot_access === 'string' && user.depot_access !== '') {
                depotAccess = user.depot_access;
            }
        }
        
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="flex items-center">
                    <div class="flex-shrink-0 h-10 w-10">
                        <div class="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                            <span class="text-green-600 font-medium text-sm">${initials}</span>
                        </div>
                    </div>
                    <div class="ml-4 min-w-0 flex-1">
                        <div class="text-sm font-medium text-gray-900 truncate" title="${escapeHtml(user.name)}">${escapeHtml(user.name)}</div>
                        <div class="text-xs text-gray-500">ID: ${user.id}</div>
                    </div>
                </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900 truncate" title="${escapeHtml(user.email)}">${escapeHtml(user.email)}</div>
                <div class="text-sm text-gray-500 truncate" title="${escapeHtml(user.phone || 'No phone')}">${escapeHtml(user.phone || 'No phone')}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                ${user.customer ? `
                    <div class="text-sm text-gray-900 truncate" title="${escapeHtml(user.customer.name || '')}">${escapeHtml(user.customer.name || 'N/A')}</div>
                    <div class="text-xs text-gray-500">Code: ${escapeHtml(user.customer.code || 'N/A')}</div>
                ` : '<div class="text-sm text-gray-500">No customer data</div>'}
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getRoleBadgeClass(user.role)}">
                    ${escapeHtml(user.role.charAt(0).toUpperCase() + user.role.slice(1))}
                </span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900 truncate" title="${escapeHtml(depotAccess)}">${escapeHtml(depotAccess)}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-center">
                <div class="flex items-center justify-center gap-3">
                    <button onclick="CustomerUsers.editUserRole(${user.id})" 
                            class="text-blue-600 hover:text-blue-900 transition-colors duration-200 p-1 hover:bg-blue-50 rounded"
                            title="Change role">
                        <i class="fas fa-user-edit text-lg"></i>
                    </button>
                    <button onclick="CustomerUsers.editUserPermissions(${user.id})" 
                            class="text-purple-600 hover:text-purple-900 transition-colors duration-200 p-1 hover:bg-purple-50 rounded"
                            title="Edit permissions">
                        <i class="fas fa-key text-lg"></i>
                    </button>
                    <button onclick="CustomerUsers.viewUserDetails(${user.id})" 
                            class="text-gray-600 hover:text-gray-900 transition-colors duration-200 p-1 hover:bg-gray-50 rounded"
                            title="View details">
                        <i class="fas fa-eye text-lg"></i>
                    </button>
                    <button onclick="CustomerUsers.suspendUser(${user.id})" 
                            class="text-red-600 hover:text-red-900 transition-colors duration-200 p-1 hover:bg-red-50 rounded"
                            title="Suspend user">
                        <i class="fas fa-ban text-lg"></i>
                    </button>
                </div>
            </td>
        `;
        return row;
    }
    
    // Get role badge class based on role
    function getRoleBadgeClass(role) {
        switch(role) {
            case 'owner':
                return 'bg-purple-100 text-purple-800';
            case 'staff':
                return 'bg-blue-100 text-blue-800';
            case 'viewer':
                return 'bg-gray-100 text-gray-800';
            default:
                return 'bg-gray-100 text-gray-800';
        }
    }
    
    // Edit user role
    function editUserRole(userId) {
        const user = activeUsersData.find(u => u.id === userId);
        if (!user) return;
        
        // TODO: Open modal to change user role
        console.log('Edit role for user:', user);
    }
    
    // Edit user permissions
    function editUserPermissions(userId) {
        const user = activeUsersData.find(u => u.id === userId);
        if (!user) return;
        
        // TODO: Open modal to edit permissions
        console.log('Edit permissions for user:', user);
    }
    
    // Suspend user
    function suspendUser(userId) {
        const user = activeUsersData.find(u => u.id === userId);
        if (!user) return;
        
        if (confirm(`Are you sure you want to suspend ${user.name}?`)) {
            // TODO: Call API to suspend user
            console.log('Suspend user:', user);
        }
    }

    // Public API
    window.CustomerUsers = {
        init: init,
        loadPendingUsers: loadPendingUsers,
        loadActiveUsers: loadActiveUsers,
        openApproveModal: openApproveModal,
        closeApproveModal: closeApproveModal,
        confirmApprove: confirmApprove,
        openRejectModal: openRejectModal,
        closeRejectModal: closeRejectModal,
        confirmReject: confirmReject,
        viewUserDetails: viewUserDetails,
        editUserRole: editUserRole,
        editUserPermissions: editUserPermissions,
        suspendUser: suspendUser
    };
    
})();